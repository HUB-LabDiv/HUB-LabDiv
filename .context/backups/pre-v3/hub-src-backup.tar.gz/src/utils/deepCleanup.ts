/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */

/**
 * HUB LAB-DIV: DEEP CLEANUP (LGPD compliance)
 * Esta função limpa todos os rastros do usuário no navegador local do cliente.
 */
export async function handleDeepCleanup() {
  if (typeof window === 'undefined') return;

  try {
    // 0. Sign out do cliente Supabase
    try {
      const { supabase } = await import('@/lib/supabase/client');
      await supabase.auth.signOut();
    } catch {
      // Ignora erro se não autenticado
    }

    // 1. Limpar LocalStorage e SessionStorage
    localStorage.clear();
    sessionStorage.clear();

    // 2. Limpar Cookies (via document.cookie)
    const cookies = document.cookie.split(";");
    for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i];
        const eqPos = cookie.indexOf("=");
        const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/";
    }

    // 3. Limpar Cache Storage (PWA / Service Workers)
    if ('caches' in window) {
      const cacheNames = await caches.keys();
      await Promise.all(cacheNames.map(name => caches.delete(name)));
    }

    // 4. Desregistrar Service Workers
    if ('serviceWorker' in navigator) {
      const registrations = await navigator.serviceWorker.getRegistrations();
      for (const registration of registrations) {
        await registration.unregister();
      }
    }

    // 5. Limpar IndexedDB (Bancos de Dados locais de bibliotecas como Supabase/Firebase)
    if (window.indexedDB && window.indexedDB.databases) {
      const dbInfo = await window.indexedDB.databases();
      dbInfo.forEach(db => {
        if (db.name) {
          window.indexedDB.deleteDatabase(db.name);
        }
      });
    }

    console.log('✅ Deep Cleanup completo: Navegador limpo de PII.');
    return true;
  } catch (error) {
    console.error('❌ Falha no Deep Cleanup:', error);
    return false;
  }
}
