/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */

import { createServerClient } from '@supabase/ssr';
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { verifyAdminToken } from './auth/admin-token';
import { getInitiativeConfigByHost } from './subdomain-urls';
import { getSharedCookieDomain } from './supabase/cookie-domain';

export async function proxy(request: NextRequest) {
    const { pathname } = request.nextUrl;
    const host = (request.headers.get('host') || '').toLowerCase();
    const initiativeConfig = getInitiativeConfigByHost(host);
    const sharedDomain = getSharedCookieDomain(host);

    let response = NextResponse.next({ request });

    // --- Supabase Session Refresh ---
    // Refreshes the auth token on every request to prevent silent logouts.
    // Uses @supabase/ssr with cookie get/set on the response object.
    const supabase = createServerClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
        {
            cookies: {
                getAll() {
                    return request.cookies.getAll();
                },
                setAll(cookiesToSet) {
                    // Forward cookies to both the request (for downstream SSR)
                    // and the response (for the browser)
                    cookiesToSet.forEach(({ name, value }) =>
                        request.cookies.set(name, value)
                    );
                    response = NextResponse.next({ request });
                    cookiesToSet.forEach(({ name, value, options }) => {
                        const mergedOptions = sharedDomain
                            ? { ...options, domain: sharedDomain }
                            : options;
                        response.cookies.set(name, value, mergedOptions);
                    });
                },
            },
        }
    );

    // Performance: Only refresh auth token on routes that need it
    // Public routes skip getUser() to save ~100-200ms TTFB and prevent DB bottleneck on media/auth
    const isInitiativePublic = (initiativeConfig && !pathname.startsWith('/painel') && !pathname.startsWith('/admin')) ||
        (pathname.startsWith('/sites/') && !pathname.includes('/painel'));

    const isPublicRoute = isInitiativePublic ||
        pathname === '/' ||
        pathname.startsWith('/gcif') ||
        pathname.startsWith('/comunidade') ||
        pathname.startsWith('/sobre') ||
        pathname.startsWith('/fluxo') ||
        pathname.startsWith('/drops') ||
        pathname.startsWith('/terms') ||
        pathname.startsWith('/privacy') ||
        pathname.startsWith('/delete-account') ||
        pathname.startsWith('/transparencia') ||
        pathname.startsWith('/login') ||
        pathname.startsWith('/auth') ||
        pathname.startsWith('/api/auth') ||
        pathname.startsWith('/api/avatar') ||
        pathname.startsWith('/api/og') ||
        pathname.startsWith('/api/webpush');

    const isProd = process.env.NODE_ENV === 'production';
    const cspHeader = `
        default-src 'self';
        script-src 'self' 'unsafe-eval' 'unsafe-inline' blob: https://*.supabase.co https://*.cloudinary.com https://*.youtube.com https://www.clarity.ms https://scripts.clarity.ms https://c.bing.com https://ajax.googleapis.com;
        style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
        img-src 'self' blob: data: https://api.dicebear.com https://*.supabase.co https://*.cloudinary.com https://storage.hublabdiv.com.br https://i.ytimg.com https://*.ytimg.com https://*.googleusercontent.com https://*.google.com https://avatars.githubusercontent.com https://*.google-analytics.com https://*.googletagmanager.com https://*.clarity.ms https://c.bing.com https://*.bing.com;
        font-src 'self' data: https://fonts.gstatic.com;
        connect-src 'self' http://localhost:3000 http://*.localhost:3000 http://127.0.0.1:3000 https://aurtistic.vercel.app https://*.vercel.app https://*.supabase.co wss://*.supabase.co https://*.cloudinary.com https://storage.hublabdiv.com.br https://*.resend.com https://fonts.googleapis.com https://*.google-analytics.com https://*.googletagmanager.com https://*.clarity.ms https://*.bing.com https://c.bing.com;
        media-src 'self' https://*.supabase.co https://*.cloudinary.com https://storage.hublabdiv.com.br https://*.youtube.com;
        frame-src 'self' http://localhost:3000 http://*.localhost:3000 http://127.0.0.1:3000 https://aurtistic.vercel.app https://*.vercel.app https://*.hublabdiv.com.br https://*.youtube.com https://*.youtube-nocookie.com;
        object-src 'none';
        base-uri 'self';
        form-action 'self';
        frame-ancestors 'none';
        block-all-mixed-content;
        ${isProd ? 'upgrade-insecure-requests;' : ''}
    `.replace(/\s{2,}/g, ' ').trim();

    const applyHeaders = (res: NextResponse) => {
        res.headers.set('Content-Security-Policy', cspHeader);
        res.headers.set('X-Frame-Options', 'DENY');
        res.headers.set('X-Content-Type-Options', 'nosniff');
        res.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
        res.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
        if (isProd) {
            res.headers.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
        }
        return res;
    };

    if (!isPublicRoute) {
        // This call triggers the token refresh if needed
        const { data: { user } } = await supabase.auth.getUser();

        // [FASE 2 e FASE 3: Gatekeepers (ECA & Termos Legados)]
        if (
            user && 
            !pathname.startsWith('/re-accept-terms') && 
            !pathname.startsWith('/terms') && 
            !pathname.startsWith('/privacy') && 
            !pathname.startsWith('/delete-account') && 
            !pathname.startsWith('/transparencia') && 
            !pathname.startsWith('/auth') && 
            !pathname.startsWith('/api/auth')
        ) {
            const { data: profile } = await supabase
                .from('profiles')
                .select('accepted_terms_version, is_adult')
                .eq('id', user.id)
                .single();

            // Gatekeeper de Termos (Fase 2)
            if (profile?.accepted_terms_version !== 'v2.0') {
                 const reacceptUrl = new URL('/re-accept-terms', request.url);
                 return applyHeaders(NextResponse.redirect(reacceptUrl));
            }

            // Gatekeeper de ECA Strict RBAC (Fase 3) - Bloqueia mutações PÚBLICAS
            if (request.method !== 'GET' && request.method !== 'HEAD' && request.method !== 'OPTIONS' && profile?.is_adult === false) {
                const isWhitelisted = 
                    pathname.startsWith('/api/feedback') || 
                    pathname.startsWith('/api/reports') ||
                    pathname.startsWith('/perguntas') ||
                    pathname.startsWith('/lab'); // Aprovado: Contato direto a pesquisadores e laboratório.

                if (!isWhitelisted) {
                    console.warn(`[ECA Gatekeeper] Interceptado e Bloqueado ${request.method} mutacional do Jovem no path: ${pathname}`);
                    return new NextResponse(
                        JSON.stringify({ error: "[ECA RBAC] Ação bloqueada pelo Sistema de Proteção. Usuário não é adulto." }),
                        { status: 403, headers: { 'content-type': 'application/json', 'Content-Security-Policy': cspHeader } }
                    );
                }
            }
        }
    }

    // --- Admin Auth Check (Hardened) ---
    if (pathname.startsWith('/admin') && !pathname.startsWith('/admin/login')) {
        // Check for cryptographically signed admin tokens (session ou bypass)
        const adminSession = request.cookies.get('admin_session')?.value;
        const adminBypass = request.cookies.get('admin_bypass')?.value;
        const bypassCheck = await verifyAdminToken(adminBypass);
        const sessionCheck = await verifyAdminToken(adminSession);
        const tokenCheck = bypassCheck.valid ? bypassCheck : sessionCheck;

        if (tokenCheck.valid && tokenCheck.role) {
            const isAdminOnlyRoute = pathname.startsWith('/admin/perigo') || 
                                   pathname.startsWith('/admin/profiles') ||
                                   pathname.startsWith('/admin/trails');
            if (isAdminOnlyRoute && tokenCheck.role !== 'admin') {
                const adminHomeUrl = new URL('/admin', request.url);
                return applyHeaders(NextResponse.redirect(adminHomeUrl));
            }
            return applyHeaders(response);
        }

        const { data: { user } } = await supabase.auth.getUser();

        if (!user) {
            const loginUrl = new URL('/admin/login', request.url);
            return applyHeaders(NextResponse.redirect(loginUrl));
        }

        // Verify role in profiles table
        const { data: profile } = await supabase
            .from('profiles')
            .select('role')
            .eq('id', user.id)
            .single();

        const role = profile?.role || 'user';

        // 1. If not admin nor moderator, kick out
        if (role !== 'admin' && role !== 'moderator') {
            const homeUrl = new URL('/', request.url);
            return applyHeaders(NextResponse.redirect(homeUrl));
        }

        // 2. Strict Admin-only routes
        const isAdminOnlyRoute = pathname.startsWith('/admin/perigo') || 
                               pathname.startsWith('/admin/profiles') ||
                               pathname.startsWith('/admin/trails');
        
        if (isAdminOnlyRoute && role !== 'admin') {
            const adminHomeUrl = new URL('/admin', request.url);
            return applyHeaders(NextResponse.redirect(adminHomeUrl));
        }
    }

    // --- Subdomínios de Iniciativas: Guarda de Acesso aos Bastidores (/painel) ---
    const isLocal = host.includes('localhost') || host.includes('127.0.0.1');
    const isPainelRoute = (initiativeConfig && pathname.startsWith('/painel')) ||
        pathname === '/painel' || pathname.startsWith('/painel/') ||
        pathname.startsWith('/sites/show-da-fisica/painel');

    if (isPainelRoute && isProd && !isLocal) {
        // 1. Checar HMAC Admin Session ou Bypass
        const adminSession = request.cookies.get('admin_session')?.value;
        const adminBypass = request.cookies.get('admin_bypass')?.value;
        const bypassCheck = await verifyAdminToken(adminBypass);
        const sessionCheck = await verifyAdminToken(adminSession);
        const tokenCheck = bypassCheck.valid ? bypassCheck : sessionCheck;

        if (!tokenCheck.valid || (tokenCheck.role !== 'admin' && tokenCheck.role !== 'moderator')) {
            const { data: { user } } = await supabase.auth.getUser();

            if (!user) {
                const loginOrigin = host.includes('localhost')
                    ? `http://localhost:${host.split(':')[1] || '3000'}`
                    : 'https://hublabdiv.com.br';
                const loginUrl = new URL(`/login?next=${encodeURIComponent(request.url)}`, loginOrigin);
                return applyHeaders(NextResponse.redirect(loginUrl));
            }

            const { data: profile } = await supabase
                .from('profiles')
                .select('role, member_initiatives')
                .eq('id', user.id)
                .single();

            const isStaff = profile?.role === 'admin' || profile?.role === 'moderator';
            const isMember = Array.isArray(profile?.member_initiatives) && profile.member_initiatives.includes('show_da_fisica');

            if (!isStaff && !isMember) {
                const forbiddenRedirect = initiativeConfig
                    ? new URL('/?restricted=1', request.url)
                    : new URL('/sites/show-da-fisica?restricted=1', request.url);
                return applyHeaders(NextResponse.redirect(forbiddenRedirect));
            }
        }
    }

    // --- Subdomínios de Iniciativas: Reescrita Transparente de Rota ---
    if (initiativeConfig && !pathname.startsWith('/api') && !pathname.startsWith('/_next')) {
        const internalFolder = `/sites/${initiativeConfig.folder}`;
        if (!pathname.startsWith(internalFolder)) {
            const internalPath = `${internalFolder}${pathname === '/' ? '' : pathname}`;
            const rewriteUrl = new URL(internalPath, request.url);
            return applyHeaders(NextResponse.rewrite(rewriteUrl, {
                headers: response.headers,
            }));
        }
    } else if (!initiativeConfig && (
        pathname === '/painel' || pathname.startsWith('/painel/') ||
        pathname === '/conheca' || pathname.startsWith('/conheca/') ||
        pathname === '/experimentos' || pathname.startsWith('/experimentos/') ||
        pathname === '/monte-seu-show' || pathname.startsWith('/monte-seu-show/') ||
        pathname === '/acompanhe' || pathname.startsWith('/acompanhe/') ||
        pathname === '/noticias-e-eventos' || pathname.startsWith('/noticias-e-eventos/')
    )) {
        // Redirecionamento amigável para desenvolvimento/preview quando acessado diretamente sem subdomínio
        const rewriteUrl = new URL(`/sites/show-da-fisica${pathname}`, request.url);
        return applyHeaders(NextResponse.rewrite(rewriteUrl, {
            headers: response.headers,
        }));
    }

    return applyHeaders(response);
}

export const config = {
    matcher: [
        // Run middleware on all routes except static files and images
        '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
    ],
};

