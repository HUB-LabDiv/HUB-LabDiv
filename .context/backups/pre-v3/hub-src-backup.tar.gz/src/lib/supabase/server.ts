/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */

import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import { getSharedCookieDomain } from './cookie-domain';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

/**
 * Supabase client for **Server-side** contexts:
 * - Route Handlers (app/api/*, app/auth/callback)
 * - Server Actions ('use server')
 * - Server Components
 *
 * This client is cookie-aware: it reads/writes auth tokens via
 * Next.js cookies(), enabling proper session persistence across
 * the SSR boundary.
 */
export async function createServerSupabase() {
    const cookieStore = await cookies();

    const client = createServerClient(supabaseUrl, supabaseAnonKey, {
        cookies: {
            getAll() {
                return cookieStore.getAll();
            },
            setAll(cookiesToSet) {
                try {
                    const sharedDomain = getSharedCookieDomain();
                    cookiesToSet.forEach(({ name, value, options }) => {
                        const mergedOptions = sharedDomain
                            ? { ...options, domain: sharedDomain }
                            : options;
                        cookieStore.set(name, value, mergedOptions);
                    });
                } catch {
                    // setAll may fail in Server Components (read-only context).
                }
            },
        },
    });

    // Impersonation Logic: Override getUser to return impersonated user if admin
    const impersonatedId = cookieStore.get('admin_impersonating_id')?.value;
    if (impersonatedId) {
        const originalGetUser = client.auth.getUser.bind(client.auth);
        client.auth.getUser = async (token?: string) => {
            const { data, error } = await originalGetUser(token);
            if (data.user && !error) {
                // Verify if the REAL user is actually an admin
                const { data: profile } = await client
                    .from('profiles')
                    .select('role')
                    .eq('id', data.user.id)
                    .single();

                if (profile?.role === 'admin') {
                    // Return a "fake" user object with the impersonated ID
                    return {
                        data: {
                            user: {
                                ...data.user,
                                id: impersonatedId,
                                // @ts-ignore - custom properties for internal tracking
                                isImpersonated: true,
                                // @ts-ignore
                                adminId: data.user.id
                            }
                        },
                        error: null
                    };
                } else {
                    // Safety: Clear cookie if user is not admin
                    cookieStore.delete('admin_impersonating_id');
                }
            }
            return { data, error } as any;
        };
    }

    return client;
}

/**
 * Supabase client for **Static/Cached** contexts:
 * - Functions wrapped with unstable_cache()
 *
 * This client is **NOT** cookie-aware. It does not call cookies(),
 * which allows it to be used inside Next.js data-cache scopes.
 * Use this only for public data that doesn't require user-specific Auth.
 */
export async function createSupabaseStatic() {
    return createServerClient(supabaseUrl, supabaseAnonKey, {
        cookies: {
            getAll() { return []; },
            setAll() { /* No-op in static context */ },
        },
    });
}
