/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */

import React, { ReactNode } from 'react';

/**
 * Utility to strip Markdown and LaTeX from a string.
 * Used for clean text previews in cards/meta tags.
 */
export function stripMarkdownAndLatex(text: string | null | undefined): string {
    if (!text) return '';

    let clean = text;

    // 1. Remove HTML tags & replace line break elements with space
    clean = clean.replace(/<br\s*\/?>/gi, ' ');
    clean = clean.replace(/<\/p>/gi, ' ');
    clean = clean.replace(/<\/h[1-6]>/gi, ' ');
    clean = clean.replace(/<[^>]*>/g, '');
    clean = clean.replace(/&nbsp;/gi, ' ');
    clean = clean.replace(/&amp;/gi, '&');
    clean = clean.replace(/&lt;/gi, '<');
    clean = clean.replace(/&gt;/gi, '>');

    // 2. Remove LaTeX Display Math: $$ ... $$ or \[ ... \]
    clean = clean.replace(/\$\$[\s\S]*?\$\$/g, '');
    clean = clean.replace(/\\\[[\s\S]*?\\\]/g, '');

    // 3. Remove LaTeX Inline Math: $ ... $ or \( ... \)
    clean = clean.replace(/\$.*?\$/g, '');
    clean = clean.replace(/\\\([\s\S]*?\\\)/g, '');

    // 4. Remove LaTeX Commands: \command{...}{...} or \command[...]{...} or \command
    clean = clean.replace(/\\[a-zA-Z*]+(?:\[.*?\])?(?:\{.*?\})*/g, '');

    // 5. Remove Markdown Links: [text](url) -> text
    clean = clean.replace(/\[(.*?)\]\(.*?\)/g, '$1');

    // 6. Remove Markdown Formatting: **, *, __, _, ~~
    clean = clean.replace(/(\*\*|__)(.*?)\1/g, '$2');
    clean = clean.replace(/(\*|_)(.*?)\1/g, '$2');
    clean = clean.replace(/~~(.*?)~~/g, '$1');

    // 7. Remove Markdown Headers: # Header
    clean = clean.replace(/^#+\s+/gm, '');

    // 8. Remove Markdown Images: ![alt](url)
    clean = clean.replace(/!\[.*?\]\(.*?\)/g, '');

    // 9. Remove Code blocks and inline code
    clean = clean.replace(/```[\s\S]*?```/g, '');
    clean = clean.replace(/`.*?`/g, '');

    // 10. Remove leftover LaTeX artifacts: { }, _, ^, \
    clean = clean.replace(/[{}_\^]/g, '');
    clean = clean.replace(/\\/g, '');

    // 11. Clean up extra whitespace/newlines
    clean = clean.replace(/\n\s*\n/g, '\n').trim();
    clean = clean.replace(/[ \t]+/g, ' ');

    return clean;
}

/**
 * Resolves avatar URLs. Direct high-speed CDN for trusted hosts (Google, Supabase, Cloudinary, GitHub, Dicebear),
 * and proxy for untrusted external sources.
 */
export function getAvatarUrl(url: string | null | undefined): string {
    if (!url) return '';
    if (url.startsWith('/') || url.startsWith('data:')) return url;

    let processedUrl = url;
    
    // Upgrade Google avatars (often end in =s96-c, forcing them to 500x500 to keep high res across UI)
    if (processedUrl.includes('googleusercontent.com')) {
        if (processedUrl.includes('=s')) {
            processedUrl = processedUrl.replace(/=s\d+-c/g, '=s500-c');
            processedUrl = processedUrl.replace(/=s\d+$/g, '=s500'); // Some don't have -c
        } else {
            processedUrl += '=s500-c';
        }
        return processedUrl;
    }

    // Upgrade GitHub avatars
    if (processedUrl.includes('githubusercontent.com')) {
        if (!processedUrl.includes('&s=') && !processedUrl.includes('?s=')) {
            processedUrl += (processedUrl.includes('?') ? '&' : '?') + 's=500';
        }
        return processedUrl;
    }

    // Direct CDN for Supabase, Cloudinary, Fire Stick, and Dicebear
    if (
        processedUrl.includes('.supabase.co') ||
        processedUrl.includes('cloudinary.com') ||
        processedUrl.includes('storage.hublabdiv.com.br') ||
        processedUrl.includes('api.dicebear.com')
    ) {
        return processedUrl;
    }

    return `/api/avatar?url=${encodeURIComponent(processedUrl)}`;
}

/**
 * Formats a date string to pt-BR.
 */
export function formatDate(dateStr: string | null | undefined): string {
    if (!dateStr) return '';
    return new Date(dateStr).toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
}

/**
 * Highlight a query match in a string, escaping special characters for React.
 */
export function highlightMatch(text: string | null | undefined, query: string): string | ReactNode {
    if (!text) return '';
    if (!query || !query.trim() || query.length < 2) return text;
    const cleanQuery = query.startsWith('#') ? query.slice(1) : query;
    const regex = new RegExp(`(${cleanQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    const parts = text.split(regex);

    return React.createElement(
        React.Fragment,
        null,
        ...parts.map((part, i) =>
            part.toLowerCase() === cleanQuery.toLowerCase() ?
                React.createElement('mark', { key: i, className: "bg-brand-yellow/40 text-gray-900 dark:text-white rounded-sm px-0.5 font-black" }, part) :
                part
        )
    );
}

import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Utility to merge Tailwind CSS classes safely.
 */
export function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}
