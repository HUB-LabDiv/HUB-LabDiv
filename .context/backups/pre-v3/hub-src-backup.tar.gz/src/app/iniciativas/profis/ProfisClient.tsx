'use client';

/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 *
 * Este programa é software livre (Licença AGPLv3)
 */

import React, { useState } from 'react';
import Link from 'next/link';
import { MainLayoutWrapper } from "@/components/layout/MainLayoutWrapper";
import {
  GraduationCap,
  BookOpen,
  Users,
  Calendar,
  Sparkles,
  LayoutDashboard,
  Palette,
  ShieldCheck,
  X,
  ExternalLink,
  ChevronRight,
  ArrowRight
} from 'lucide-react';
import { Breadcrumbs } from '@/components/wiki/WikiComponents';
import { AurtisticOrgEmbedFrame } from '@/components/aurtistic/AurtisticOrgEmbedFrame';

export function ProfisClient() {
  const [isMemberModalOpen, setIsMemberModalOpen] = useState(false);
  const [embedMode, setEmbedMode] = useState<'org' | 'studio'>('org');

  return (
    <MainLayoutWrapper fullWidth={true}>
      <div className="max-w-7xl mx-auto px-4 py-8 animate-in fade-in slide-in-from-bottom-5 duration-700">
        <Breadcrumbs
          title="Pró-Física (ProFis)"
          section="Iniciativas de Impacto"
          sectionHref="/gcif/instituto"
          backHref="/gcif/instituto"
        />

        {/* Hero Section */}
        <div className="relative overflow-hidden rounded-[36px] bg-gradient-to-br from-[#131a2e] via-[#0d1322] to-[#070b14] border border-amber-500/30 p-8 md:p-12 mb-12 shadow-2xl">
          <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-1/4 w-80 h-80 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold uppercase tracking-wider">
              <GraduationCap className="w-4 h-4 text-amber-400" />
              <span>Ensino • Nivelamento &amp; Apoio Acadêmico</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-black font-bukra text-white tracking-tight uppercase">
              Pró-Física <span className="text-amber-400">(ProFis)</span>
            </h1>

            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              O Programa Pró-Física do IFUSP apoia calouros e graduandos na transição para a universidade,
              oferecendo plantões de dúvidas, monitorias temáticas de Cálculo e Física Básica, além de
              seminários e nivelamento conceitual.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a
                href="#eixo4"
                className="px-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs md:text-sm shadow-lg hover:scale-105 transition-all flex items-center gap-2 cursor-pointer"
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Área do Membro (Eixo 4)</span>
              </a>

              <a
                href="https://fep.if.usp.br/~profis/"
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs md:text-sm border border-white/20 hover:scale-105 transition-all flex items-center gap-2"
              >
                <span>Site Oficial ProFis</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        {/* Pilares do ProFis */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          <div className="p-6 rounded-3xl bg-[#0b101d] border border-amber-500/20 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <BookOpen className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white font-bukra">Plantões de Cálculo</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Monitorias semanais para Cálculo Diferencial e Integral I e II, com resolução de listas e reforço pré-provas.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-[#0b101d] border border-sky-500/20 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white font-bukra">Física Básica I a IV</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Nivelamento de Mecânica, Termodinâmica, Eletromagnetismo e Óptica para os cursos de Física e engenharias.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-[#0b101d] border border-emerald-500/20 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white font-bukra">Mentoria entre Pares</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Acolhimento aos ingressantes, dicas de organização de estudos e integração com a comunidade acadêmica do IFUSP.
            </p>
          </div>
        </section>

        {/* Gestão de Tarefas e Posts — Botão do Painel de Membro (Eixo 4) */}
        <section id="eixo4" className="mb-20 scroll-mt-24">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#12182b] via-[#0d1424] to-[#080d18] border border-amber-500/30 p-6 md:p-8 shadow-2xl">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
              <div className="space-y-2 max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase tracking-wider">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  <span>Área do Membro • Pró-Física (ProFis)</span>
                </div>
                <h3 className="text-xl md:text-3xl font-black text-white font-bukra">
                  Painel de Gestão &amp; HUB Studio
                </h3>
                <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
                  Acesso restrito à equipe de monitores e coordenadores do ProFis credenciados no painel de gestão.
                  Membros entram automaticamente via SSO do HUB; novos monitores utilizam o código de convite.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setEmbedMode('org');
                    setIsMemberModalOpen(true);
                  }}
                  className="px-5 py-3 rounded-2xl bg-[#FFCC00] hover:bg-[#ffe066] text-slate-950 font-black text-xs md:text-sm shadow-lg hover:scale-105 transition-all flex items-center gap-2 cursor-pointer"
                >
                  <LayoutDashboard className="w-4 h-4" />
                  <span>Acessar Painel do Membro</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEmbedMode('studio');
                    setIsMemberModalOpen(true);
                  }}
                  className="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs md:text-sm border border-white/20 hover:scale-105 transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Palette className="w-4 h-4 text-cyan-400" />
                  <span>HUB Studio</span>
                </button>
              </div>
            </div>

            {/* Modal em Tela Cheia do Painel do Membro / Studio */}
            {isMemberModalOpen && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
                <div className="w-full max-w-6xl h-[92vh] bg-[#070b18] border border-amber-500/40 rounded-3xl shadow-2xl flex flex-col overflow-hidden relative">
                  {/* Header do Modal */}
                  <div className="flex items-center justify-between px-5 py-3.5 bg-black/70 border-b border-white/10">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center">
                        <ShieldCheck className="w-4 h-4 text-amber-300" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white flex items-center gap-2">
                          <span>Painel de Membro Pró-Física</span>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                            {embedMode === 'studio' ? 'HUB Studio' : 'Aurtistic Gestão'}
                          </span>
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          Equipe credenciada pelo administrador • Autenticação segura SSO
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setIsMemberModalOpen(false)}
                      className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                      title="Fechar Painel"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Iframe Embutido Lazy */}
                  <div className="flex-1 overflow-hidden flex flex-col">
                    <AurtisticOrgEmbedFrame
                      orgSlug="profis"
                      mode={embedMode}
                      heightClassName="h-full"
                      allowOrgSwitch={false}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>
      </div>
    </MainLayoutWrapper>
  );
}
