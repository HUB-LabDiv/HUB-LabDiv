'use client';

/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 */

import React, { useState } from 'react';
import Link from 'next/link';
import { MainLayoutWrapper } from "@/components/layout/MainLayoutWrapper";
import { ArrowRight, LayoutDashboard, Palette, Lock, X, ShieldCheck } from 'lucide-react';
import { PostDTO } from '@/dtos/media';
import { MediaCard } from '@/components/media/MediaCard';
import { Breadcrumbs } from '@/components/wiki/WikiComponents';
import { AurtisticOrgEmbedFrame } from '@/components/aurtistic/AurtisticOrgEmbedFrame';

interface LabdivClientProps {
    posts: PostDTO[];
}

export function LabdivClient({ posts }: LabdivClientProps) {
    const [isMemberModalOpen, setIsMemberModalOpen] = useState(false);
    const [embedMode, setEmbedMode] = useState<'org' | 'studio'>('org');
    return (
        <MainLayoutWrapper fullWidth={true}>
            <div className="max-w-7xl mx-auto px-4 py-8 animate-in fade-in slide-in-from-bottom-5 duration-700">
                <Breadcrumbs 
                    title="Lab-Div" 
                    section="Iniciativas de Impacto" 
                    sectionHref="/gcif/instituto" 
                    backHref="/gcif/instituto" 
                />

                {/* Hero Lab-Div */}
                <section className="relative overflow-hidden py-16 bg-gradient-to-br from-brand-blue/10 via-white to-brand-red/5 dark:from-brand-blue/20 dark:via-background-dark dark:to-brand-red/10 border border-gray-200 dark:border-gray-800 rounded-3xl mb-12 text-left">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 flex flex-col md:flex-row items-center gap-8">
                        <div className="flex-1">
                            <h2 className="font-display font-bold text-4xl md:text-5xl tracking-tight mb-4 text-gray-900 dark:text-white">
                                O que é o <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-blue via-brand-red to-brand-yellow">Lab-Div</span>?
                            </h2>
                            <p className="text-lg text-gray-600 dark:text-gray-400 mb-8 max-w-2xl">
                                É um laboratório de divulgação científica que produz, reúne e ajuda a criar material de divulgação científica para melhorar a divulgação científica do IF.
                            </p>

                            <div className="flex flex-wrap gap-4 mt-8">
                                <Link 
                                    href="/iniciativas/hub" 
                                    className="px-6 py-3 bg-brand-yellow text-[#121212] rounded-2xl font-black uppercase tracking-widest text-[11px] shadow-xl shadow-brand-yellow/20 flex items-center gap-2 hover:-translate-y-1 transition-transform"
                                >
                                    <span className="material-symbols-outlined text-[20px]">hub</span>
                                    Sobre o HUB
                                </Link>
                                <a 
                                    href="https://sites.google.com/usp.br/labdiv/in%C3%ADcio" 
                                    target="_blank" 
                                    rel="noopener noreferrer" 
                                    className="px-6 py-3 bg-white/10 dark:bg-white/5 border border-brand-blue/30 text-brand-blue rounded-2xl font-black uppercase tracking-widest text-[11px] backdrop-blur-md flex items-center gap-2 hover:-translate-y-1 transition-transform"
                                >
                                    <span className="material-symbols-outlined text-[20px]">language</span>
                                    Site Oficial
                                </a>
                                <a 
                                    href="https://sites.google.com/usp.br/labdiv/people?authuser=0" 
                                    target="_blank" 
                                    rel="noopener noreferrer" 
                                    className="px-6 py-3 bg-brand-blue text-white rounded-2xl font-black uppercase tracking-widest text-[11px] shadow-xl shadow-brand-blue/20 flex items-center gap-2 hover:-translate-y-1 transition-transform"
                                >
                                    <span className="material-symbols-outlined text-[20px]">groups</span>
                                    Conhecer a Equipe
                                </a>
                            </div>
                        </div>
                        <div className="hidden md:block w-48 h-48 relative opacity-80">
                            <div className="absolute inset-0 bg-gradient-to-tr from-brand-blue to-brand-red rounded-full blur-3xl opacity-20 animate-pulse" />
                            <span className="material-symbols-outlined text-[120px] text-brand-blue drop-shadow-2xl absolute inset-0 flex items-center justify-center">library_books</span>
                        </div>
                    </div>
                </section>

                {/* Section About Lab-Div */}
                <div className="bg-gradient-to-br from-brand-blue/5 to-brand-red/5 dark:from-blue-900/10 dark:to-red-900/10 rounded-3xl p-8 md:p-12 border border-brand-blue/10 mb-20">
                    <div className="flex flex-col md:flex-row items-center gap-10">
                        <div className="flex-1">
                            <h2 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white uppercase italic tracking-tighter">
                                O Papel do <span className="text-brand-blue">Lab-Div</span>
                            </h2>
                            <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed mb-8">
                                O Laboratório de Divulgação Científica do IFUSP atua como o motor técnico e curatorial desta plataforma. Inspirado no modelo do <strong>MIT Comm Lab</strong>, nosso trabalho se estende da produção de conteúdo &quot;Padrão Ouro&quot; à moderação, suporte e mentoria contínua para garantir a qualidade da comunicação.
                            </p>
                            <div className="flex flex-wrap gap-4">
                                <a 
                                    href="https://sites.google.com/usp.br/labdiv/in%C3%ADcio" 
                                    target="_blank" 
                                    rel="noopener noreferrer" 
                                    className="px-6 py-3 bg-brand-blue text-white rounded-xl font-black uppercase tracking-widest text-[10px] shadow-lg shadow-brand-blue/20 flex items-center gap-2 hover:scale-105 transition-transform"
                                >
                                    <span className="material-symbols-outlined text-[18px]">launch</span>
                                    Conferir o Site
                                </a>
                                <a 
                                    href="https://sites.google.com/usp.br/labdiv/joinus?authuser=0" 
                                    target="_blank" 
                                    rel="noopener noreferrer" 
                                    className="px-6 py-3 bg-brand-red text-white rounded-xl font-black uppercase tracking-widest text-[10px] shadow-lg shadow-brand-red/20 flex items-center gap-2 hover:scale-105 transition-transform"
                                >
                                    <span className="material-symbols-outlined text-[18px]">person_add</span>
                                    Venha fazer parte
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Premium CTAs */}
                <section className="py-4 max-w-7xl mx-auto mb-16 text-left">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
                        {/* Kit Div CTA */}
                        <div className="relative overflow-hidden bg-gradient-to-br from-brand-red/10 to-transparent dark:from-brand-red/20 dark:to-card-dark rounded-3xl p-5 md:p-8 border border-brand-red/20 hover:border-brand-red/40 transition-colors group flex flex-row md:flex-col gap-4 md:gap-0 items-start">
                            <div className="w-12 h-12 bg-white dark:bg-gray-900 rounded-2xl flex shrink-0 items-center justify-center md:mb-6 shadow-sm">
                                <span className="material-symbols-outlined text-brand-red text-2xl">inventory_2</span>
                            </div>
                            <div className="flex-1 flex flex-col relative z-10 h-full">
                                <h3 className="text-lg md:text-2xl font-bold text-gray-900 dark:text-white mb-1 md:mb-2">Kit Div</h3>
                                <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400 mb-4 md:mb-8 max-w-sm">
                                    Ferramentas, templates, guias de linguagem e assets audiovisuais da marca do IFUSP para acelerar produções.
                                </p>
                                <a href="https://sites.google.com/usp.br/labdiv/kitdiv?authuser=0" target="_blank" rel="noopener noreferrer" className="mt-auto px-4 md:px-6 py-2 md:py-3 bg-brand-red text-white text-[11px] md:text-sm font-bold rounded-xl flex w-fit items-center gap-2 hover:scale-105 transition-transform group-hover:shadow-lg group-hover:shadow-brand-red/20">
                                    Explorar Kit
                                    <span className="material-symbols-outlined text-[16px] group-hover:translate-x-1 transition-transform">arrow_forward</span>
                                </a>
                            </div>
                        </div>

                        {/* Mentoria CTA */}
                        <div className="relative overflow-hidden bg-gradient-to-br from-brand-blue/10 to-transparent dark:from-brand-blue/20 dark:to-card-dark rounded-3xl p-5 md:p-8 border border-brand-blue/20 hover:border-brand-blue/40 transition-colors group flex flex-row md:flex-col gap-4 md:gap-0 items-start">
                            <div className="absolute top-0 right-0 p-4 md:p-8 opacity-10 rotate-12 group-hover:rotate-0 transition-transform duration-500 hidden sm:block">
                                <span className="material-symbols-outlined text-[80px] md:text-[120px] text-brand-blue">psychology</span>
                            </div>
                            <div className="w-12 h-12 bg-white dark:bg-gray-900 rounded-2xl flex shrink-0 items-center justify-center md:mb-6 shadow-sm">
                                <span className="material-symbols-outlined text-brand-blue text-2xl">group_add</span>
                            </div>
                            <div className="flex-1 flex flex-col relative z-10 h-full">
                                <h3 className="text-lg md:text-2xl font-bold text-gray-900 dark:text-white mb-1 md:mb-2">Mentoria Premium</h3>
                                <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400 mb-4 md:mb-8 max-w-sm">
                                    Agende reuniões com Veteranos para revisar roteiros, artigos e refinar a didática das suas produções.
                                </p>
                                <a href="https://sites.google.com/usp.br/labdiv/schedule?authuser=0" target="_blank" rel="noopener noreferrer" className="mt-auto px-4 md:px-6 py-2 md:py-3 bg-brand-blue text-white text-[11px] md:text-sm font-bold rounded-xl flex w-fit items-center gap-2 hover:scale-105 transition-transform group-hover:shadow-lg group-hover:shadow-brand-blue/20">
                                    Solicitar Mentoria
                                    <span className="material-symbols-outlined text-[16px] group-hover:translate-x-1 transition-transform">arrow_forward</span>
                                </a>
                            </div>
                        </div>

                        {/* DigitaLab CTA */}
                        <div className="relative overflow-hidden bg-gradient-to-br from-brand-yellow/10 to-transparent dark:from-brand-yellow/20 dark:to-card-dark rounded-3xl p-5 md:p-8 border border-brand-yellow/20 hover:border-brand-yellow/40 transition-colors group flex flex-row md:flex-col gap-4 md:gap-0 items-start">
                            <div className="absolute top-0 right-0 p-4 md:p-8 opacity-10 rotate-6 group-hover:rotate-0 transition-transform duration-500 hidden sm:block">
                                <span className="material-symbols-outlined text-[80px] md:text-[120px] text-brand-yellow">meeting_room</span>
                            </div>
                            <div className="w-12 h-12 bg-white dark:bg-gray-900 rounded-2xl flex shrink-0 items-center justify-center md:mb-6 shadow-sm">
                                <span className="material-symbols-outlined text-brand-yellow text-2xl">event_available</span>
                            </div>
                            <div className="flex-1 flex flex-col relative z-10 h-full w-full">
                                <h3 className="text-lg md:text-2xl font-bold text-gray-900 dark:text-white mb-1 md:mb-2 leading-tight">DigitaLab</h3>
                                <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400 mb-4 md:mb-8 max-w-sm">
                                    Um espaço multimídia do IFUSP disponível para gravações, reuniões e eventos acadêmicos.
                                </p>
                                <a href="https://sites.google.com/usp.br/labdiv/digitalab?authuser=0" target="_blank" rel="noopener noreferrer" className="mt-auto px-4 md:px-6 py-2 md:py-3 bg-brand-yellow text-gray-900 text-[11px] md:text-sm font-bold rounded-xl flex w-fit items-center gap-1 hover:scale-105 transition-transform group-hover:shadow-lg group-hover:shadow-brand-yellow/20">
                                    Agendar Espaço
                                    <span className="material-symbols-outlined text-[14px] group-hover:translate-x-1 transition-transform">arrow_forward</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </section>

                {/* Lab-Div Posts Carousel */}
                {posts && posts.length > 0 && (
                    <section className="mb-16">
                        <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 uppercase italic tracking-tighter">
                            Produções Recentes
                        </h3>
                        <div className="flex overflow-x-auto gap-4 pb-6 snap-x hide-scrollbar">
                            {posts.map(post => (
                                <div key={post.id} className="min-w-[300px] sm:min-w-[350px] max-w-[350px] snap-center">
                                    <MediaCard post={post} />
                                </div>
                            ))}
                        </div>
                    </section>
                )}

                {/* Gestão de Tarefas e Posts — Botão do Painel de Membro (Eixo 4) */}
                <section id="eixo4" className="mb-20 scroll-mt-24">
                    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#0b1329] via-[#0f1d3d] to-[#070b18] border border-cyan-500/30 p-6 md:p-8 shadow-2xl">
                        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
                            <div className="space-y-2 max-w-2xl">
                                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-bold uppercase tracking-wider">
                                    <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                                    <span>Área do Membro • LabDiv</span>
                                </div>
                                <h3 className="text-xl md:text-3xl font-black text-white font-bukra">
                                    Painel de Gestão &amp; HUB Studio
                                </h3>
                                <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
                                    Acesso restrito à equipe credenciada pelo administrador no painel de gestão. 
                                    Membros entram automaticamente via SSO do HUB; novos participantes utilizam o código de convite.
                                </p>
                            </div>

                            <div className="flex flex-wrap items-center gap-3 shrink-0">
                                <button
                                    type="button"
                                    onClick={() => {
                                        setEmbedMode('org');
                                        setIsMemberModalOpen(true);
                                    }}
                                    className="px-5 py-3 rounded-2xl bg-[#FFCC00] hover:bg-[#ffe066] text-slate-950 font-black text-xs md:text-sm shadow-lg hover:scale-105 transition-all flex items-center gap-2 cursor-pointer"
                                >
                                    <LayoutDashboard className="w-4 h-4" />
                                    <span>Acessar Painel do Membro</span>
                                </button>
                                <button
                                    type="button"
                                    onClick={() => {
                                        setEmbedMode('studio');
                                        setIsMemberModalOpen(true);
                                    }}
                                    className="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs md:text-sm border border-white/20 hover:scale-105 transition-all flex items-center gap-2 cursor-pointer"
                                >
                                    <Palette className="w-4 h-4 text-cyan-400" />
                                    <span>HUB Studio</span>
                                </button>
                            </div>
                        </div>

                        {/* Modal em Tela Cheia do Painel do Membro / Studio */}
                        {isMemberModalOpen && (
                            <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
                                <div className="w-full max-w-6xl h-[92vh] bg-[#070b18] border border-cyan-500/40 rounded-3xl shadow-2xl flex flex-col overflow-hidden relative">
                                    {/* Header do Modal */}
                                    <div className="flex items-center justify-between px-5 py-3.5 bg-black/70 border-b border-white/10">
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center">
                                                <ShieldCheck className="w-4 h-4 text-cyan-300" />
                                            </div>
                                            <div>
                                                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                                                    <span>Painel de Membro LabDiv</span>
                                                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                                        {embedMode === 'studio' ? 'HUB Studio' : 'Aurtistic Gestão'}
                                                    </span>
                                                </h4>
                                                <p className="text-[11px] text-slate-400">
                                                    Equipe credenciada pelo administrador • Autenticação segura
                                                </p>
                                            </div>
                                        </div>

                                        <button
                                            type="button"
                                            onClick={() => setIsMemberModalOpen(false)}
                                            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                                            title="Fechar Painel"
                                        >
                                            <X className="w-5 h-5" />
                                        </button>
                                    </div>

                                    {/* Iframe Embutido Lazy */}
                                    <div className="flex-1 overflow-hidden flex flex-col">
                                        <AurtisticOrgEmbedFrame
                                            orgSlug="labdiv"
                                            mode={embedMode}
                                            heightClassName="h-full"
                                            allowOrgSwitch={false}
                                        />
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </section>
            </div>
        </MainLayoutWrapper>
    );
}
