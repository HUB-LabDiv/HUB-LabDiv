/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */

import { createServerSupabase } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import { MatchPageClient } from './MatchPageClient';

export const metadata = {
    title: 'Match Acadêmico | IFUSP',
    description: 'Encontre colegas com interesses acadêmicos compatíveis.',
};

export default async function FerramentasMatchPage() {
    const supabase = await createServerSupabase();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
        redirect('/login');
    }

    const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

    if (!profile) {
        redirect('/lab');
    }

    // Merge pending edits so the user sees their latest interest signal immediately
    const mergedProfile = {
        ...profile,
        ...(profile.pending_edits || {})
    };

    return <MatchPageClient profile={mergedProfile} />;
}
