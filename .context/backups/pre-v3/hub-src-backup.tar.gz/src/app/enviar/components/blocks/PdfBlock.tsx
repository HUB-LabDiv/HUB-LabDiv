/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 *
 * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 *
 * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */

import React, { useState } from 'react';
import { Block } from '@/app/enviar/schema';
import { useSubmissionStore } from '@/store/useSubmissionStore';
import { CloudinaryUploader } from './CloudinaryUploader';
import { usePendingUploadsStore } from '@/store/usePendingUploadsStore';
import { getPdfViewerUrl, getPdfEmbedUrl } from '@/lib/media-utils';
import { BlockAccessibilityFields } from './BlockAccessibilityFields';

export default function PdfBlock({ block, isActive }: { block: Block; isActive: boolean }) {
    const { updateBlock } = useSubmissionStore();
    const pendingFiles = usePendingUploadsStore((state) => state.pendingFiles);
    const pdfUrl = block.content.url || '';
    const caption = block.content.caption || '';
    const altText = block.content.altText || '';

    const isOrphaned = pdfUrl.startsWith('blob:') && !pendingFiles[pdfUrl];

    /** URL processada (corrige transformações Cloudinary, extensão, etc.) */
    const viewerUrl = getPdfViewerUrl(pdfUrl);
    const embedUrl = getPdfEmbedUrl(pdfUrl);

    return (
        <div className="flex flex-col gap-4">
            {!pdfUrl ? (
                <div className="w-full min-h-[12rem] border-2 border-dashed border-brand-red/30 rounded-xl flex flex-col items-center justify-center text-gray-300 transition-colors bg-brand-red/10 p-6">
                    <span className="material-symbols-outlined text-4xl mb-2 text-brand-red">picture_as_pdf</span>
                    <span className="text-sm font-medium mb-4">Adicione um PDF</span>
                    
                    <CloudinaryUploader 
                        accept=".pdf,application/pdf"
                        label="Upload de PDF"
                        icon="upload_file"
                        resourceType="raw"
                        onUploadSuccess={(url) => updateBlock(block.id, { url })}
                    />
                    
                    <div className="flex items-center gap-4 w-3/4 mt-4 opacity-50">
                        <div className="flex-1 h-px bg-brand-red/50"></div>
                        <span className="text-xs uppercase tracking-widest font-bold">OU</span>
                        <div className="flex-1 h-px bg-brand-red/50"></div>
                    </div>

                    <input 
                        type="url" 
                        placeholder="Cole o link do PDF, ou link de pasta do Drive (se arquivo > 10MB)..."
                        className="mt-4 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg outline-none focus:border-brand-red text-white text-sm w-3/4 text-center transition-colors hover:border-brand-red/50 font-sans"
                        value={pdfUrl}
                        onChange={(e) => updateBlock(block.id, { url: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                    />
                </div>
            ) : (
                <div className="flex flex-col gap-2">
                    {/* Alerta de PDF Expirado */}
                    {isOrphaned && (
                        <div className="p-3 bg-brand-red/15 border border-brand-red/60 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-pulse">
                            <div className="flex items-center gap-2.5">
                                <span className="material-symbols-outlined text-brand-red text-2xl shrink-0">error</span>
                                <div className="flex flex-col">
                                    <span className="text-xs font-black text-brand-red uppercase tracking-wider">PDF Expirado / Erro de Envio</span>
                                    <span className="text-[11px] text-gray-200">O arquivo PDF local expirou da sessão. Reenvie o arquivo para publicar.</span>
                                </div>
                            </div>
                            <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                                <div className="scale-90 origin-right">
                                    <CloudinaryUploader 
                                        accept=".pdf,application/pdf"
                                        label="Reenviar PDF"
                                        icon="sync"
                                        resourceType="raw"
                                        onUploadSuccess={(url) => updateBlock(block.id, { url })}
                                    />
                                </div>
                                <button
                                    onClick={() => updateBlock(block.id, { url: '' })}
                                    className="px-2.5 py-1.5 bg-brand-red/20 hover:bg-brand-red text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1"
                                    title="Remover PDF"
                                >
                                    <span className="material-symbols-outlined text-[16px]">delete</span>
                                </button>
                            </div>
                        </div>
                    )}

                    <div className={`relative group rounded-xl overflow-hidden bg-gray-900 border ${isOrphaned ? 'border-brand-red ring-2 ring-brand-red/30' : 'border-gray-800'} h-[500px]`}>
                        {pdfUrl.includes('drive.google') ? (
                            <div className="w-full h-full flex flex-col items-center justify-center text-gray-400 bg-gray-800/30">
                                <span className="material-symbols-outlined text-4xl mb-2 text-gray-200">folder_zip</span>
                                <span className="text-sm font-bold uppercase tracking-widest text-gray-200 mb-2">Pasta do Google Drive</span>
                                <a href={pdfUrl} target="_blank" rel="noopener noreferrer" className="text-xs hover:text-white transition-colors underline decoration-brand-red underline-offset-4">Acessar Materiais (Upload &gt; 10MB)</a>
                            </div>
                        ) : (
                            <iframe 
                                src={embedUrl} 
                                className="w-full h-full"
                                title={caption || altText || "PDF Viewer"}
                            />
                        )}

                        {/* Barra inferior com ações */}
                        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3 flex items-center justify-between opacity-0 group-hover:opacity-100 transition-opacity">
                            <a
                                href={viewerUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-800/80 hover:bg-gray-700 text-gray-300 hover:text-white text-xs font-bold rounded-lg transition-colors uppercase tracking-wider"
                                onClick={(e) => e.stopPropagation()}
                            >
                                <span className="material-symbols-outlined text-[14px]">open_in_new</span>
                                Abrir PDF
                            </a>
                            {isActive && (
                                <button 
                                    onClick={() => updateBlock(block.id, { url: '' })}
                                    className="px-3 py-1.5 bg-brand-red/80 hover:bg-brand-red text-white text-xs font-bold rounded-lg transition-colors uppercase tracking-wider"
                                >
                                    Remover
                                </button>
                            )}
                        </div>
                    </div>

                    {caption && !isActive && (
                        <p className="text-xs text-gray-400 text-center italic mt-1 font-sans">
                            {caption}
                        </p>
                    )}
                </div>
            )}

            {/* Painel Padronizado de Acessibilidade e Legenda para PDF */}
            <BlockAccessibilityFields
                caption={caption}
                altText={altText}
                onCaptionChange={(val) => updateBlock(block.id, { caption: val })}
                onAltTextChange={(val) => updateBlock(block.id, { altText: val })}
                captionLabel="Legenda / Identificação do Documento PDF"
                captionPlaceholder="Ex: Relatório técnico completo sobre o método de medição..."
                altTextLabel="Resumo de Acessibilidade (Leitores de Tela)"
                altTextPlaceholder="Resuma os tópicos principais e conclusões do PDF para pessoas com deficiência..."
                isActive={isActive}
            />
        </div>
    );
}
