/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */

export const CATEGORIES = [
    {
        id: 'Arte',
        title: 'Galeria',
        description: 'Expressões artísticas da comunidade: desenhos, pinturas, poemas e outras artes criativas.',
        icon: 'palette',
        color: 'brand-yellow',
        examples: 'Ilustrações científicas, poesias, artes digitais.'
    },
    {
        id: 'Lab-Div',
        title: 'Lab-Div',
        description: 'Conteúdos oficiais, comunicados e projetos do Laboratório de Divulgação Científica.',
        icon: 'science',
        color: 'brand-blue',
        examples: 'Divulgações oficiais, parcerias, comunicados Lab-Div.'
    },
    {
        id: 'Mentorados Lab-Div',
        title: 'Mentorados Lab-Div',
        description: 'Produções desenvolvidas por alunos participantes das mentorias do Lab-Div.',
        icon: 'psychology',
        color: 'brand-yellow',
        examples: 'Projetos de mentorados, evoluções de divulgação.'
    },
    {
        id: 'Laboratórios',
        title: 'Laboratórios',
        description: 'Fotos e vídeos de experimentos, equipamentos e infraestrutura de pesquisa.',
        icon: 'biotech',
        color: 'brand-blue',
        examples: 'Montagens ópticas, vácuo, criogenia, lasers.'
    },
    {
        id: 'Pesquisadores',
        title: 'Pesquisadores',
        description: 'A cara da ciência: cientistas em ação no laboratório ou campo.',
        icon: 'person_search',
        color: 'brand-red',
        examples: 'Alunos e professores trabalhando, discussões no quadro.'
    },
    {
        id: 'Bastidores da Ciência',
        title: 'Bastidores da Ciência',
        description: 'O dia a dia real: o que ninguém vê na publicação final.',
        icon: 'visibility',
        color: 'brand-yellow',
        examples: 'Preparação de amostras, limpeza, organização.'
    },
    {
        id: 'Eventos',
        title: 'Eventos',
        description: 'Congressos, palestras, workshops e visitas institucionais.',
        icon: 'event',
        color: 'brand-red',
        examples: 'Fotos de pôsteres, auditórios, coffee breaks.'
    },
    {
        id: 'Nossa História',
        title: 'Nossa História',
        description: 'Relíquias, fotos antigas e marcos da história do Instituto de Física.',
        icon: 'history_edu',
        color: 'brand-blue',
        examples: 'Fotos de 1934, antigos laboratórios, grandes descobertas.'
    },
    {
        id: 'Uso Didático',
        title: 'Uso Didático',
        description: 'Experimentos e materiais voltados para o ensino de graduação.',
        icon: 'menu_book',
        color: 'brand-yellow',
        examples: 'Experimentos da Física I, II, III e IV.'
    },
    {
        id: 'Convivência',
        title: 'Convivência',
        description: 'Momentos de lazer e integração na comunidade do IF.',
        icon: 'groups',
        color: 'brand-red',
        examples: 'Copa, festas, reuniões informais.'
    },
    {
        id: 'Central de Anotações',
        title: 'Central de Anotações',
        description: 'Materiais de estudo, notas de aula e resumos compartilhados.',
        icon: 'description',
        color: 'brand-yellow',
        examples: 'PDFs de notas, resumos escritos, sdocx.'
    },
    {
        id: 'Mural do Deu Ruim',
        title: 'Mural do Deu Ruim',
        description: 'Falhas, erros e desafios que fazem parte do aprendizado científico.',
        icon: 'report_problem',
        color: 'brand-red',
        examples: 'Equipamentos quebrados, códigos com erro, resultados inesperados.'
    },
    {
        id: 'Outros',
        title: 'Outros',
        description: 'Conteúdos que não se encaixam nas categorias acima.',
        icon: 'more_horiz',
        color: 'gray-500',
        examples: 'Qualquer outra contribuição relevante.'
    }
];

export const FORMATS = [
    {
        id: 'image',
        title: 'Fotos',
        description: 'Até 10 imagens (JPG, PNG, GIF). Máx 10MB.',
        icon: 'image',
        color: 'brand-blue'
    },
    {
        id: 'video',
        title: 'Vídeo',
        description: 'Links do YouTube hospedados externamente.',
        icon: 'smart_display',
        color: 'brand-red'
    },
    {
        id: 'pdf',
        title: 'PDF',
        description: 'Documentos e resumos. Máx 10MB.',
        icon: 'picture_as_pdf',
        color: 'brand-yellow'
    },
    {
        id: 'zip',
        title: 'ZIP',
        description: 'Agrupamentos de arquivos. Máx 10MB.',
        icon: 'folder_zip',
        color: 'brand-blue'
    },
    {
        id: 'sdocx',
        title: 'Notes',
        description: 'Samsung Notes nativo. Máx 10MB.',
        icon: 'edit_note',
        color: 'brand-red'
    },
    {
        id: 'text',
        title: 'Texto',
        description: 'Postagem direta em Markdown e LaTeX.',
        icon: 'article',
        color: 'brand-blue'
    },
    {
        id: 'audio',
        title: 'Áudio',
        description: 'Gravações e sons (MP3, WAV, OGG). Máx 10MB.',
        icon: 'mic',
        color: 'brand-yellow'
    }
];
