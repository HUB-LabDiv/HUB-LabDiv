/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 *
 * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 *
 * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */

import { redirect } from 'next/navigation';

export const dynamic = 'force-dynamic';

export const metadata = {
    title: 'Redirecionando para o Servidor de Storage & Portfólio...',
    description: 'Servidor próprio de armazenamento do HUB LabDiv e Portfólio no Fire TV Stick.',
};

export default function StoragePage() {
    const storageUrl = process.env.NEXT_PUBLIC_STORAGE_BASE_URL || 'https://storage.hublabdiv.com.br';
    redirect(storageUrl);
}

