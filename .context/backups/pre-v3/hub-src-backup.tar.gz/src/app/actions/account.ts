'use server';

/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */


import { createServerSupabase } from '@/lib/supabase/server';
import { createAdminSupabase } from '@/lib/supabase/admin';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';

/**
 * TAREFA 1: Takeout de Dados (Portabilidade LGPD)
 * Reúne todas as informações do usuário e gera um objeto estruturado.
 */
export async function exportUserData() {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    throw new Error('Usuário não autenticado');
  }

  const userId = user.id;

  // Busca paralela de todos os dados do usuário
  const [
    profile,
    submissions,
    articles,
    comments,
    questions,
    follows,
    followers,
    likes,
    saved,
    dicasVeteranos,
    wikiArticles,
    hubAdoptions,
    reproductions,
    readingHistory,
    entanglementMessages
  ] = await Promise.all([
    supabase.from('profiles').select('*').eq('id', userId).single(),
    supabase.from('submissions').select('*').eq('user_id', userId),
    supabase.from('micro_articles').select('*').eq('author_id', userId),
    supabase.from('comments').select('*').eq('user_id', userId),
    supabase.from('perguntas').select('*').eq('email', user.email),
    supabase.from('follows').select('*').eq('follower_id', userId),
    supabase.from('follows').select('*').eq('following_id', userId),
    supabase.from('curtidas').select('*').eq('user_id', userId),
    supabase.from('saved_posts').select('*').eq('user_id', userId),
    supabase.from('dicas_veteranos').select('*').eq('autor_id', userId),
    supabase.from('wiki_articles').select('*').eq('author_id', userId),
    supabase.from('hub_adoptions').select('*').eq('user_id', userId),
    supabase.from('reproductions').select('*').eq('user_id', userId),
    supabase.from('reading_history').select('*').eq('user_id', userId),
    supabase.from('entanglement_messages').select('*').eq('sender_id', userId)
  ]);

  const exportData = {
    metadata: {
      exported_at: new Date().toISOString(),
      platform: 'HUB Lab-Div',
      version: '1.0',
    },
    user_info: user,
    profile: profile.data,
    content: {
      submissions: submissions.data || [],
      articles: articles.data || [],
      comments: comments.data || [],
      questions: questions.data || [],
      dicas_veteranos: dicasVeteranos.data || [],
      wiki_articles: wikiArticles.data || [],
      hub_adoptions: hubAdoptions.data || [],
      reproductions: reproductions.data || []
    },
    social: {
      following_count: follows.data?.length || 0,
      followers_count: followers.data?.length || 0,
      likes_given: likes.data || [],
      saved_items: saved.data || [],
      entanglement_messages: entanglementMessages.data || []
    },
    history: {
      reading_history: readingHistory.data || []
    }
  };

  return exportData;
}

/**
 * TAREFA 3: Gatilho de Exclusão (Inicia o processo)
 * Nota: A exclusão real de auth.users deve ser feita via API Route 
 * usando a service_role_key, pois Server Actions usam a role do usuário.
 */
export async function requestAccountDeletion() {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return { error: 'Sessão expirada' };
  }

  // A UI chamará a API Route /api/account/delete com o token da sessão
  return { success: true };
}

/**
 * TAREFA 4: Exclusão Seletiva de Dados
 * Apaga categorias específicas de dados sem excluir a conta principal.
 */
export async function deleteSpecificUserData(categories: string[]) {
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return { success: false, error: 'Usuário não autenticado' };
  }

  const userId = user.id;
  const userEmail = user.email;

  try {
    const adminSupabase = createAdminSupabase();
    const GHOST_UUID = '00000000-0000-0000-0000-000000000000';

    for (const category of categories) {
      switch (category) {
        case 'submissions':
          // Submissões (Fluxo) são CC obrigatório, portanto anonimizadas
          await adminSupabase.from('submissions').update({ user_id: GHOST_UUID }).eq('user_id', userId);
          break;
        case 'comments':
          // Comentários acompanham o fluxo científico, também anonimizados
          await adminSupabase.from('comments').update({ user_id: GHOST_UUID }).eq('user_id', userId);
          break;
        case 'articles':
          // Micro Artigos (Arte/Drops) têm CC opcional, portanto são deletados
          await adminSupabase.from('micro_articles').delete().eq('author_id', userId);
          break;
        case 'questions':
          if (userEmail) {
            await adminSupabase.from('perguntas').delete().eq('email', userEmail);
          }
          break;
        case 'interactions':
          await Promise.all([
            adminSupabase.from('curtidas').delete().eq('user_id', userId),
            adminSupabase.from('saved_posts').delete().eq('user_id', userId),
            adminSupabase.from('follows').delete().eq('follower_id', userId)
          ]);
          break;
        default:
          console.warn('Categoria desconhecida para exclusão:', category);
      }
    }

    revalidatePath('/conta');
    revalidatePath('/lab');
    
    return { success: true };
  } catch (error) {
    console.error('Erro ao excluir dados específicos:', error);
    return { success: false, error: 'Erro ao processar exclusão no banco de dados.' };
  }
}
