'use server';

/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */


import { createServerSupabase } from '@/lib/supabase/server';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';

const CreateDropSchema = z.object({
    content: z.string().trim().min(1, 'O conteúdo não pode estar vazio').max(2000, 'Máximo de 2000 caracteres'),
    parentId: z.string().uuid().optional().nullable()
});

const ReactDropSchema = z.object({
    dropId: z.string().uuid(),
    reactionType: z.enum(['up', 'down'])
});

export async function createDrop(content: string, parentId?: string) {
    const parse = CreateDropSchema.safeParse({ content, parentId });
    if (!parse.success) {
        return { error: parse.error.issues[0]?.message || 'Dados inválidos' };
    }

    const supabase = await createServerSupabase();
    
    // 1. Get User
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { error: 'Você precisa estar logado para postar.' };

    // 2. Insert Drop (Forçando status 'pending' para moderação)
    const { data: drop, error } = await supabase
        .from('micro_articles')
        .insert({
            author_id: user.id,
            content: parse.data.content,
            parent_id: parse.data.parentId || null,
            status: 'pending' // CLÁUSULA 2: Segurança e Aprovação
        })
        .select(`
            *,
            profiles:author_id (
                username
            )
        `)
        .single();

    if (error) {
        console.error('Error creating drop:', error);
        return { error: 'Erro ao salvar o log no banco de dados.' };
    }

    // 3. Trigger Email Notification (Non-blocking)
    try {
        const dropProfiles = drop.profiles as { username?: string | null } | { username?: string | null }[] | null;
        const dropProfile = Array.isArray(dropProfiles) ? dropProfiles[0] : dropProfiles;
        const username = dropProfile?.username || user.email?.split('@')[0] || 'membro';
        
        const { sendAdminNotification } = await import('@/lib/notifications.server');
        await sendAdminNotification({
            type: parentId ? 'thread_reply' : 'drop_submission',
            content: content.trim(),
            userName: username
        });
    } catch (notifyError) {
        console.error('Failed to send drop notification email:', notifyError);
    }

    revalidatePath('/');
    revalidatePath('/admin/drops');
    
    return { success: true, data: drop };
}

export async function fetchThreads(parentId: string) {
    const supabase = await createServerSupabase();
    
    const { data, error } = await supabase
        .from('micro_articles')
        .select(`
            *,
            likes_count,
            dislikes_count,
            profiles:author_id (
                name:full_name,
                handle:username,
                avatar:avatar_url,
                user_category,
                research_line,
                course,
                interest_area
            )
        `)
        .eq('parent_id', parentId)
        .eq('status', 'approved')
        .neq('moderation_status', 'suspended')
        .order('created_at', { ascending: true });

    if (error) {
        console.error('Error fetching threads:', error);
        return { error: 'Erro ao carregar fios.' };
    }

    const { data: { user } } = await supabase.auth.getUser();

    // Buscando contagem de respostas e reação do usuário para cada thread
    const threadsWithContext = await Promise.all((data || []).map(async (thread) => {
        // Contagem de respostas
        const { count } = await supabase
            .from('micro_articles')
            .select('*', { count: 'exact', head: true })
            .eq('parent_id', thread.id)
            .eq('status', 'approved')
            .neq('moderation_status', 'suspended');

        // Reação do usuário atual
        let userReaction = null;
        if (user) {
            const { data: reaction } = await supabase
                .from('micro_article_likes')
                .select('reaction_type')
                .eq('article_id', thread.id)
                .eq('user_id', user.id)
                .single();
            userReaction = reaction?.reaction_type || null;
        }

        return { 
            ...thread, 
            replies_count: count || 0,
            user_reaction: userReaction
        };
    }));

    return { data: threadsWithContext };
}

export async function reactToDrop(dropId: string, reactionType: 'up' | 'down') {
    const parse = ReactDropSchema.safeParse({ dropId, reactionType });
    if (!parse.success) {
        return { error: 'Parâmetros de reação inválidos' };
    }

    const supabase = await createServerSupabase();
    const { data: { user } } = await supabase.auth.getUser();
    
    // Identificador único (User ID ou Fingerprint se quisermos permitir deslogado, mas usaremos user aqui)
    if (!user) return { error: 'Faça login para reagir.' };

    const validDropId = parse.data.dropId;
    const validReactionType = parse.data.reactionType;

    // 1. Verificar reação existente
    const { data: existing } = await supabase
        .from('micro_article_likes')
        .select('*')
        .eq('article_id', validDropId)
        .eq('user_id', user.id)
        .maybeSingle();

    if (existing) {
        if (existing.reaction_type === reactionType) {
            // Remover reação se for a mesma
            await supabase.from('micro_article_likes').delete().eq('id', existing.id);
            // Decrementar contador correspondente
            const column = reactionType === 'up' ? 'likes_count' : 'dislikes_count';
            await supabase.rpc('increment_micro_article_counter', { 
                article_id: dropId, 
                counter_column: column, 
                increment_by: -1 
            });
        } else {
            // Mudar tipo de reação
            await supabase
                .from('micro_article_likes')
                .update({ reaction_type: reactionType })
                .eq('id', existing.id);
            
            // Ajustar contadores
            if (reactionType === 'up') {
                await supabase.rpc('adjust_micro_article_reactions', {
                    article_id: dropId,
                    up_inc: 1,
                    down_inc: -1
                });
            } else {
                await supabase.rpc('adjust_micro_article_reactions', {
                    article_id: dropId,
                    up_inc: -1,
                    down_inc: 1
                });
            }
        }
    } else {
        // Nova reação
        await supabase.from('micro_article_likes').insert({
            article_id: dropId,
            user_id: user.id,
            reaction_type: reactionType
        });
        
        // Incrementar contador
        const column = reactionType === 'up' ? 'likes_count' : 'dislikes_count';
        await supabase.rpc('increment_micro_article_counter', { 
            article_id: dropId, 
            counter_column: column, 
            increment_by: 1 
        });
    }

    revalidatePath('/');
    return { success: true };
}

export async function fetchUserDrops(userId: string) {
    const supabase = await createServerSupabase();
    
    const { data, error } = await supabase
        .from('micro_articles')
        .select(`
            *,
            profiles:author_id (
                id,
                username,
                full_name,
                avatar_url,
                level,
                title,
                user_category
            ),
            replies:micro_articles!parent_id (count)
        `)
        .eq('author_id', userId)
        .order('created_at', { ascending: false });

    if (error) {
        const { data: plainData } = await supabase
            .from('micro_articles')
            .select('*')
            .eq('author_id', userId)
            .order('created_at', { ascending: false });
        return plainData || [];
    }

    return data || [];
}
