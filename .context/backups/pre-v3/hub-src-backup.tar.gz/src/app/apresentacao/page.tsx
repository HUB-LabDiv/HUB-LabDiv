/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */

import { Metadata } from 'next';
import { Orbitron } from 'next/font/google';
import { ApresentacaoClient } from './ApresentacaoClient';

const orbitron = Orbitron({ subsets: ['latin'], weight: ['400', '700', '900'] });

export const metadata: Metadata = {
    title: 'Apresentação do HUB | LabDiv',
    description: 'A história, funcionamento e engenharia por trás do HUB LabDiv.',
};

export default function ApresentacaoPage() {
    return <ApresentacaoClient orbitronClassName={orbitron.className} />;
}
