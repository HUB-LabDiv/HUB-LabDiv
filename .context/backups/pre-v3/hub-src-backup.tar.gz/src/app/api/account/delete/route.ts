/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */

import { createAdminSupabase } from '@/lib/supabase/admin';
import { createServerSupabase } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

export async function POST(req: Request) {
  try {
    const cookieStore = await cookies();
    
    // 1. Verificar Autenticação (Session)
    const supabaseSession = await createServerSupabase();
    const { data: { user }, error: authError } = await supabaseSession.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    const userId = user.id;

    // 2. Cliente com Service Role (Privilégios de Admin)
    const supabaseAdmin = createAdminSupabase();

    // 2.1 Limpar arquivos de avatar no Supabase Storage (LGPD Art. 18, VI & Google Play Data Safety)
    try {
      const { data: avatarFiles } = await supabaseAdmin.storage
        .from('avatars')
        .list(userId);

      if (avatarFiles && avatarFiles.length > 0) {
        const filePaths = avatarFiles.map(f => `${userId}/${f.name}`);
        await supabaseAdmin.storage.from('avatars').remove(filePaths);
      }
    } catch (storageErr) {
      console.warn('Aviso: falha não-bloqueante na remoção de arquivos de avatar do Storage:', storageErr);
    }

    // 3. Executar o Soft Delete via RPC (Lógica MK5)
    // A RPC no god-sql-mk5.sql cuida da anonimização e deleção de auth.users
    const { error: rpcError } = await supabaseAdmin.rpc('soft_delete_user', {
      target_user_id: userId
    });

    if (rpcError) {
      console.error('ERRO CRÍTICO NA RPC DE EXCLUSÃO (Soft Delete):', {
        message: rpcError.message,
        details: rpcError.details,
        hint: rpcError.hint,
        code: rpcError.code
      });
      return NextResponse.json({ 
        error: 'Falha ao processar exclusão no banco de dados',
        details: rpcError.message 
      }, { status: 500 });
    }

    // 4. Limpar Cookies de Segurança e Sessão
    cookieStore.delete('admin_impersonating_id');
    
    // O client-side deve rodar o deepCleanup no browser.
    return NextResponse.json({ 
      success: true, 
      message: 'Sua conta foi excluída com sucesso. Todos os dados sensíveis foram removidos.' 
    });

  } catch (err: any) {
    console.error('Erro crítico na rota de exclusão:', err);
    return NextResponse.json({ error: 'Erro interno no servidor' }, { status: 500 });
  }
}
