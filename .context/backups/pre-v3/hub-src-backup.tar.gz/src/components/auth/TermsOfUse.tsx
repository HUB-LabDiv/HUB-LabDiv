/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */

import React from 'react';
import Link from 'next/link';

interface TermsOfUseProps {
  onAccept?: () => void;
  acceptedVersion?: string;
}

export function TermsOfUse({ onAccept, acceptedVersion }: TermsOfUseProps) {
  return (
    <div className="flex flex-col h-full max-h-[60vh] overflow-hidden bg-white dark:bg-[#1E1E1E] rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm font-open-sans">
      <div className="p-5 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-background-dark">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <h3 className="text-lg font-bold text-[#0F4780] dark:text-brand-blue uppercase tracking-tight">
            Termos de Uso e LGPD (HUB Lab-Div)
          </h3>
          <div className="flex items-center gap-3 text-xs">
            <Link href="/terms" target="_blank" className="text-brand-blue font-bold hover:underline">
              Versão Completa dos Termos ↗
            </Link>
            <Link href="/privacy" target="_blank" className="text-brand-yellow font-bold hover:underline">
              Política de Privacidade ↗
            </Link>
          </div>
        </div>
        <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mt-1 italic">Versão: v3.0 (Em vigor)</p>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
        <section>
          <h4 className="font-semibold text-gray-900 dark:text-gray-100 text-base mb-2">
            1. Consentimento e Interações no HUB v3.0
          </h4>
          <p>
            O acesso a ferramentas de pesquisa por menores de idade requer validação. O processamento de dados obedece à <strong>LGPD</strong>, <strong>ECA</strong> e <strong>Marco Civil da Internet</strong>.
            Nesta nova versão do HUB, interações como Avaliações, Comentários, Reports e Dicas de Veteranos geram XP (Gamificação). Você concorda que suas interações públicas fazem parte do ecossistema educacional colaborativo.
          </p>
        </section>

        <section>
          <h4 className="font-semibold text-gray-900 dark:text-gray-100 text-base mb-2">
            2. Licenciamento de Conteúdo (CC BY 4.0)
          </h4>
          <div className="bg-blue-50 dark:bg-[#0F4780]/10 border-l-4 border-[#0F4780] p-4 rounded-r-md">
            <p className="font-medium text-[#0F4780] dark:text-blue-300">
              ATENÇÃO: Todo Conteúdo Gerado pelo Usuário (UGC) neste HUB é regido pela Licença Creative Commons Atribuição 4.0 Internacional (CC BY 4.0).
            </p>
          </div>
          <p className="mt-3">
            Ao submeter perguntas, resoluções, wikis, quizzes ou qualquer outra interação pública, o usuário concorda que estes materiais poderão ser usados por terceiros, aprimorados, readaptados e indexados para benefício da ciência, mediante atribuição ao autor.
          </p>
        </section>

        <section>
          <h4 className="font-semibold text-gray-900 dark:text-gray-100 text-base mb-2">
            3. Direito de Retenção e Deleção de Conta
          </h4>
          <p>
            Caso você solicite a exclusão de sua conta, reservamo-nos o direito de retenção autoral e científica. Seu perfil pessoal, foto, e-mail e dados identificáveis serão definitivamente deletados. 
            Contudo, conteúdos públicos previamente submetidos serão mantidos na plataforma no formato de <strong>Anonimizados ("Usuário Excluído")</strong>, para preservar o histórico colaborativo da rede científica.
          </p>
          <p className="mt-2 font-medium text-brand-blue dark:text-brand-blue">
            O usuário tem o direito de solicitar a portabilidade de seus dados a qualquer momento através da ferramenta de exportação estruturada disponível nas configurações.
          </p>
        </section>

        <section>
          <h4 className="font-semibold text-gray-900 dark:text-gray-100 text-base mb-2">
            4. Código de Conduta
          </h4>
          <p>
            Qualquer uso da plataforma para assédio, spam, quebra de propriedade intelectual alheia não regida perante a respectiva licença, ou exploração inadequada acarretará no banimento e encaminhamento de logs criptografados (por retenção semestral do Marco Civil) para medidas cabíveis.
          </p>
        </section>

        <section>
          <h4 className="font-semibold text-gray-900 dark:text-gray-100 text-base mb-2">
            5. Finalidade Institucional e Comunicação Científica
          </h4>
          <p>
            O HUB Lab-Div atua como um laboratório de comunicação científica interativa, aproximando a sociedade do cotidiano acadêmico do IFUSP. O conteúdo reflete o processo dinâmico de pesquisa e aprendizado de alunos e pesquisadores; portanto, a plataforma não garante a acurácia absoluta ou caráter definitivo das postagens. O valor reside na transparência institucional e no debate acadêmico em tempo real, servindo como uma ferramenta de aproximação entre a Universidade e o público geral, promovendo o entendimento de como a ciência é organizada e produzida.
          </p>
        </section>
      </div>

      {onAccept && (
        <div className="p-4 bg-gray-50 dark:bg-[#181818] border-t border-gray-100 dark:border-gray-800 flex justify-end items-center gap-3">
          <button 
            type="button"
            onClick={onAccept}
            disabled={acceptedVersion === 'v3.0'}
            className={`px-6 py-3 rounded-xl font-bukra font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2 border-2 ${
              acceptedVersion === 'v3.0'
                ? 'bg-emerald-600 border-emerald-400 text-white shadow-md shadow-emerald-600/20 cursor-default'
                : 'bg-brand-yellow hover:bg-[#f5c300] border-brand-yellow text-gray-950 shadow-lg shadow-brand-yellow/25 hover:scale-105 active:scale-95 cursor-pointer'
            }`}
          >
            <span className="material-symbols-outlined text-lg font-bold">
              {acceptedVersion === 'v3.0' ? 'check_circle' : 'check_box_outline_blank'}
            </span>
            <span>
              {acceptedVersion === 'v3.0' ? 'Termos de Uso Aceitos (v3.0)' : 'Li, Entendi e Aceito os Termos (v3.0)'}
            </span>
          </button>
        </div>
      )}
    </div>
  );
}
