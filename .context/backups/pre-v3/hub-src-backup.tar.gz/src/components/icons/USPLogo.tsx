"use client";

/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */


import React from "react";
import { cn } from "@/lib/utils";

interface USPLogoProps {
  className?: string;
  size?: number | string;
}

/**
 * USPLogo - Logotipo Oficial da Universidade de São Paulo.
 * Reconstrução SVG fiel ao manual de identidade visual.
 */
export function USPLogo({ className, size = 40 }: USPLogoProps) {
  return (
    <svg
      width={size}
      height={typeof size === 'number' ? Math.round(size * (156 / 321)) : size}
      viewBox="0 0 321 156"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("shrink-0", className)}
    >
      <g transform="translate(0,156) scale(0.1,-0.1)" fill="currentColor" stroke="none">
        <path d="M212 853 c3 -506 0 -479 70 -559 61 -69 85 -74 390 -74 180 0 284 4
310 12 22 6 61 31 87 54 l48 43 34 -36 c67 -70 80 -73 394 -73 273 0 281 1
331 24 101 47 144 134 144 290 l0 91 -213 213 -213 213 -24 -26 -24 -26 197
-197 197 -197 0 -93 c0 -105 -18 -155 -69 -191 -49 -35 -117 -43 -358 -39
-191 3 -233 6 -259 20 -48 26 -93 84 -100 128 -6 37 -9 40 -39 40 -29 0 -33
-4 -45 -42 -16 -57 -42 -91 -88 -120 -36 -23 -42 -23 -304 -23 l-266 0 -44 30
c-25 18 -52 49 -66 75 -22 44 -22 49 -22 442 l0 398 180 0 180 0 0 -360 0
-360 38 0 37 0 0 357 0 358 180 5 180 5 0 35 0 35 -433 3 -433 2 3 -457z"/>
        <path d="M1277 1299 c-58 -14 -91 -34 -134 -83 -51 -58 -63 -101 -63 -227 l0
-104 208 -208 208 -208 24 26 24 26 -197 197 -197 197 0 87 c0 124 22 168 102
209 34 17 61 19 294 19 240 0 261 -1 300 -21 46 -22 83 -70 93 -123 6 -27 11
-31 41 -31 30 0 35 4 40 31 10 46 38 87 78 114 35 25 38 25 291 28 141 2 271
0 289 -3 40 -7 101 -59 118 -102 10 -24 14 -90 14 -253 l0 -220 -180 0 -180 0
0 200 0 200 -35 0 -35 0 -2 -382 -3 -383 -178 -3 -178 -2 3 -31 3 -30 213 -2
212 -2 0 182 0 183 218 2 217 3 0 255 c0 291 -3 308 -72 381 -74 80 -96 84
-398 84 -296 0 -312 -3 -386 -72 l-48 -45 -37 37 c-75 75 -97 80 -379 82 -137
1 -267 -2 -288 -8z"/>
      </g>
    </svg>
  );
}
