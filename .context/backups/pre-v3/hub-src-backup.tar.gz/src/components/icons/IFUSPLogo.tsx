"use client";

/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */


import React from "react";
import { cn } from "@/lib/utils";

interface IFUSPLogoProps {
  className?: string;
  size?: number | string;
}

/**
 * IFUSPLogo - Logotipo Oficial do Instituto de Física da USP.
 * Reconstrução SVG fiel ao manual de identidade visual.
 */
export function IFUSPLogo({ className, size = 32 }: IFUSPLogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 238 225"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("shrink-0", className)}
    >
      <g transform="translate(0,225) scale(0.1,-0.1)" fill="currentColor" stroke="none">
        <path d="M1123 2069 c-42 -21 -79 -61 -101 -112 -8 -19 -12 -90 -12 -212 l0
-185 45 0 45 0 0 170 c0 186 6 212 56 245 53 34 123 16 161 -42 16 -25 18 -59
18 -358 0 -324 0 -331 23 -376 37 -76 113 -119 211 -119 55 0 65 5 246 111
105 61 200 123 213 138 40 45 54 91 50 158 -4 69 -20 97 -82 147 -32 26 -47
31 -106 34 l-70 4 -187 -103 c-103 -57 -190 -105 -195 -107 -4 -2 -8 101 -8
230 0 205 -3 238 -19 273 -50 108 -183 156 -288 104z m807 -504 c16 -8 36 -25
44 -37 22 -31 20 -90 -4 -120 -10 -14 -100 -73 -199 -132 -174 -104 -182 -108
-223 -101 -24 4 -53 13 -65 21 -32 20 -55 69 -51 112 3 37 4 37 208 154 212
122 236 131 290 103z"/>
        <path d="M497 1695 c-104 -36 -156 -165 -112 -273 25 -57 47 -75 237 -190 98
-59 178 -109 178 -112 0 -3 -84 -52 -187 -110 -103 -58 -199 -116 -215 -129
-104 -86 -80 -276 42 -339 37 -19 57 -23 110 -19 60 3 77 10 222 91 l158 88
-22 39 c-12 22 -25 39 -30 39 -4 0 -75 -38 -157 -85 -83 -47 -160 -85 -171
-85 -63 0 -120 57 -120 118 0 64 31 89 315 249 167 94 282 164 301 186 70 76
71 207 3 290 -30 36 -358 230 -420 247 -46 13 -86 12 -132 -5z m284 -180 c96
-53 181 -106 190 -118 31 -39 41 -92 25 -130 -12 -30 -71 -87 -89 -87 -3 0
-99 55 -212 121 -216 127 -235 144 -235 209 0 36 32 87 64 101 40 17 83 1 257
-96z"/>
        <path d="M1691 1030 l-22 -39 155 -91 c163 -96 180 -114 178 -181 -2 -63 -71
-118 -134 -105 -16 3 -145 74 -286 158 -141 84 -273 158 -292 165 -51 18 -109
15 -160 -8 -56 -25 -86 -53 -113 -104 -21 -38 -22 -50 -19 -280 3 -207 6 -244
22 -275 80 -156 305 -143 374 22 13 29 16 79 16 235 0 109 4 204 9 212 7 10
54 -13 209 -103 189 -111 202 -117 256 -117 180 -3 279 192 171 337 -19 25
-316 214 -336 214 -3 0 -15 -18 -28 -40z m-420 -191 l49 -21 0 -230 c0 -256
-5 -283 -62 -318 -40 -24 -85 -26 -116 -4 -45 31 -50 57 -54 280 l-3 211 29
37 c25 33 72 64 99 66 5 0 31 -10 58 -21z"/>
      </g>
    </svg>
  );
}
