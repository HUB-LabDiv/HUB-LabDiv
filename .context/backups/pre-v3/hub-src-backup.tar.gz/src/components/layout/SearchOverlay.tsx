'use client';

/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */


import React, { useState, useEffect, useCallback, useRef } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { disciplinesData } from '@/data/disciplinesData';

// ── Wiki content for deep keyword + body-text search ──
// `content` contains all text rendered on each wiki page for full-text search
const wikiEntries = [
    {
        title: 'Guia de Boas Práticas',
        href: '/wiki/guia-de-boas-praticas',
        desc: 'Diretrizes para produção de mídia: fotografia, vídeo e créditos.',
        keywords: ['guia', 'boas práticas', 'manual', 'foto', 'vídeo', 'créditos', 'qualidade', 'padrões'],
        content: 'Estrutura em 4 Etapas formulário Categoria Formato Detalhes Básicos obrigatórios Detalhes Complementares opcionais título impactante autor principal apelido acadêmico ano trabalho descrição upload arquivos 10MB link YouTube WhatsApp Tags Coautores Links Externos Drive GitHub Notion Detalhes Técnicos ISO Câmera Software Depoimento pessoal Apelidos Identidade Apelido Acadêmico nome exibição público Nomes ofensivos integridade comunidade Links Externos Grandes Arquivos limite upload 10MB datasets PDFs códigos campo Link Externo Google Drive Mini Quiz Gamificação Engajamento 2 perguntas conteúdo XP Hub recompensar comunidade Creative Commons CC-BY-SA conhecimento créditos',
    },
    {
        title: 'Emissão de Luz — Divulgação',
        href: '/wiki/divulgacao',
        desc: 'Toolkit de divulgação: VR, posters, design e impacto visual.',
        keywords: ['divulgação', 'design', '360', 'vr', 'poster', 'mídia', 'comunicação', 'impacto', 'toolkit'],
        content: 'Fotografia Essencial Regra dos Terços intersecções grade equilíbrio ângulos tridimensionalidade equipamentos Iluminação Modo Pro ISO baixo 100-400 ruído Tempo Obturador congelar fenômenos alta energia celular bloqueio foco exposição Redação Divulgação gancho porquê mecanismo impacto Divulgação científica transporte conceitos complexos mentes curiosas Recursos Lab-Div KitDiv assets visuais tipografia oficial Mentoria equipe técnica comunicação',
    },
    {
        title: 'Interações de Fronteira — Extensão',
        href: '/wiki/extensao',
        desc: 'Extensão: grupos, eventos Física para Todos e projetos culturais.',
        keywords: ['extensão', 'cultura', 'eventos', 'física para todos', 'grupos', 'projetos'],
        content: 'Mapeamento Grupos IFUSP coletivos transformam vivência acadêmica Vaca Esférica Rádio divulgação científica alunos LabDiv Laboratório Design Comunicação Show de Física experimentos público escolar Guia Integração Aquário vivência reuniões abertas colaboração força fundamental Amélia Império espaço Colisor HS Humanidades Debates éticos Síncrotron Pontes Docentes IC Professores pesquisadores Iniciação Científica proatividade email formal apresentar interesse sala conversar brevemente',
    },
    {
        title: 'Iniciação de Partículas — Calouro',
        href: '/wiki/calouro',
        desc: 'Guia de sobrevivência: bandejão, CRUSP, JúpiterWeb e vida no campus.',
        keywords: ['bandejão', 'crusp', 'matão', 'sobrevivência', 'calouro', 'ajuda', 'logística', 'jupiter', 'sas', 'campus'],
        content: 'Mobilidade Circulares BUSP 8082-10 8083-10 8084-10 8085-10 fins semana madrugadas 8012-10 8022-10 cartão BUSP obrigatório gratuidade tarifa cobrada Bilhete Único Guia Bandejão Física mais próximo Central mais preferido Prefeitura melhor avaliado recarregar créditos RU Card aplicativo Cardápio USP PIX PAPFE sistema carrega créditos automaticamente Esporte Lazer CEPEUSP CEPE piscinas quadras academia gratuitas exame médico carteirinha USP digital liberar estresse provas Burocracia Infraestrutura Seção de Alunos trancamentos matrículas Pró-Aluno lanhouse instituto PCs computadores relatórios experimentos imprimir listas pesquisas PROFIS apoio pesquisa professores física recursos didáticos projetos ensino docentes licenciatura Networking Acadêmico Professores pesquisadores Iniciação Científica proatividade email formal sala conversar',
    },
    {
        title: 'Protocolos de Proteção',
        href: '/wiki/protecao',
        desc: 'Saúde mental, neurodiversidade (TEA), acolhimento e inclusão.',
        keywords: ['proteção', 'saúde mental', 'tea', 'neurodiversidade', 'acolhimento', 'suporte', 'inclusão', 'bem-estar', 'pcd', 'psicológico'],
        content: 'Acolhimento IFUSP Portal orientação apoio conflito escuta instituto Física Acolhe iniciativa suporte direto alunos ambiente acadêmico saudável integrado Direitos Inclusão Autismo TEA Portaria PRIP 059 avaliações salas separadas fones ouvido abafadores ruído conforto sensorial Programa ECOS Bandejão Central escuta acolhimento conflitos orientação institucional escutas pontuais comunidade Sistema USP Acolhimento SUA PRIP denúncias assédio discriminação violações direitos humanos Hospital Universitário HU acompanhamento psiquiátrico comunidade USP triagem encaminhamento consulta',
    },
    {
        title: 'Vetores de Carreira',
        href: '/wiki/carreira',
        desc: 'Trajetórias pós-IFUSP: academia, indústria, física médica e educação.',
        keywords: ['carreira', 'futuro', 'trabalho', 'indústria', 'academia', 'pós-graduação', 'ensino', 'vagas'],
        content: 'em desenvolvimento caminhos graduação formação carreiras acadêmicas mercado trabalho novas fronteiras físicos',
    },
    {
        title: 'Iniciação Científica & Laboratórios',
        href: '/wiki/pesquisa',
        desc: 'Como conseguir IC, contatar orientador, departamentos do IFUSP e editais PIBIC/PIBITI.',
        keywords: ['pesquisa', 'ic', 'iniciação científica', 'laboratório', 'ateneu', 'atena', 'orientador', 'ciência', 'pibic', 'pibiti', 'fapesp', 'siicusp', 'lattes', 'email formal'],
        content: 'professores são pesquisadores melhor forma conseguir iniciação científica proatividade mande email formal apresente interesse pergunte ir sala conversar brevemente linhas pesquisa departamentos base teorica ateneu atena pibic pibiti fapesp siicusp livros clássicos preparação',
    },
    {
        title: 'Energia de Permanência — Bolsas',
        href: '/wiki/bolsas',
        desc: 'Auxílios PAPFE, editais de monitoria e suporte estudantil.',
        keywords: ['bolsas', 'papfe', 'permanência', 'monitoria', 'dinheiro', 'editais', 'auxílio'],
        content: 'PAPFE Programa Apoio Permanência Formação Estudantil auxílios fundamentais alimentação transporte manutenção vulnerabilidade socioeconômica inscrição anual PRIP CRUSP Moradia Estudantil Conjunto Residencial USP moradia gratuita campus convivência suporte Bolsas Docência Licenciatura PIBID iniciação docência escolas públicas PROIAD monitoria apoio pedagógico SEDUC rede estadual São Paulo PEEG Programa Estímulo Ensino Graduação monitoria acadêmica materiais didáticos PUB Programa Unificado Bolsas Ensino Pesquisa Extensão Cultura PIBIC Pesquisa Acadêmica iniciação científica metodologia pensamento crítico PIBITI Inovação Desenvolvimento Tecnológico protótipos Pro-Aluno apoios institucionais Seção Alunos PRIP Pró-Reitoria Inclusão Pertencimento editais chamadas abertas',
    },
    {
        title: 'Estrutura da Matéria — Cursos IFUSP',
        href: '/wiki/ifusp',
        desc: 'Cursos, PPPs, departamentos e estrutura curricular.',
        keywords: ['ppp', 'bacharelado', 'licenciatura', 'física médica', 'grade', 'optativas', 'atpa', 'comissão'],
        content: 'em desenvolvimento Projetos Político-Pedagógicos PPPs manual habilitação créditos necessários grade matérias semestres horas Atividades Extensão AEx formar',
    },
    {
        title: 'O Instituto de Física',
        href: '/gcif/instituto',
        desc: 'História, departamentos, espaços e organização do IFUSP.',
        keywords: ['ifusp', 'instituto', 'física', 'departamento', 'auditório', 'história', 'mapa'],
        content: 'em desenvolvimento organização Instituto Física Diretoria Conselhos Comissões história pioneirismo excelência departamentos centros pesquisa cotidiano',
    },
    {
        title: 'Quiz — Teste de Radiação',
        href: '/wiki/quiz',
        desc: 'Desafie seus conhecimentos sobre o IFUSP e a física.',
        keywords: ['quiz', 'teste', 'desafio', 'conhecimento', 'ranking'],
        content: 'Contador Geiger questões técnicas históricas explodir perfil Hub colidido impacto comunidade Curiosidades IF acelerador Pelletron inaugurado 1972 patrimônio científico Rua Matão Desafios Física problemas conceituais rápidos neurônios colisões mentais',
    },
];

// ── Helper para normalização de acentos e diacríticos ──
const normalizeSearchText = (text: string): string => {
    return (text || '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .trim();
};

interface NavRoute {
    label: string;
    href: string;
    icon: string;
    color: string;
    desc: string;
    category: string;
    keywords: string[];
}

// ── Navigation routes (Auditoria Completa V3.0) ──
const navRoutes: NavRoute[] = [
    // Ferramentas Acadêmicas
    { 
        label: 'Acompanhar Semestre (Grade Horária)', 
        href: '/ferramentas', 
        icon: 'calendar_month', 
        color: 'text-brand-yellow', 
        desc: 'Acompanhamento do semestre: horários, controle de faltas e cronograma',
        category: 'Ferramentas Acadêmicas',
        keywords: ['semestre', 'grade', 'horario', 'cronograma', 'acompanhamento', 'faltas', 'estudos', 'aulas', 'disciplinas', 'jupiter'] 
    },
    { 
        label: 'Acompanhar Curso (Trilhas Curriculares)', 
        href: '/ferramentas/trilhas', 
        icon: 'route', 
        color: 'text-brand-yellow', 
        desc: 'Acompanhamento do curso: fluxo curricular, matérias concluídas e Júpiter',
        category: 'Ferramentas Acadêmicas',
        keywords: ['curso', 'trilhas', 'aprendizado', 'acompanhamento', 'disciplinas', 'jupiter', 'curriculo', 'fluxograma', 'obrigatorias', 'eletivas'] 
    },
    { 
        label: 'Central de Anotações', 
        href: '/ferramentas/anotacoes', 
        icon: 'menu_book', 
        color: 'text-brand-blue-accent', 
        desc: 'Auxílio nos estudos com cadernos de matérias e anotações acadêmicas',
        category: 'Ferramentas Acadêmicas',
        keywords: ['anotacoes', 'cadernos', 'resumos', 'estudos', 'auxilio', 'materias', 'notas', 'bloco', 'anotar'] 
    },
    { 
        label: 'Softwares da Comunidade', 
        href: '/ferramentas/softwares', 
        icon: 'laptop_chromebook', 
        color: 'text-brand-blue-accent', 
        desc: 'Auxílio nos estudos com softwares e ferramentas desenvolvidos pela comunidade',
        category: 'Ferramentas Acadêmicas',
        keywords: ['softwares', 'comunidade', 'programas', 'auxilio', 'estudos', 'python', 'matlab', 'root', 'simulacao', 'computacao', 'ferramentas'] 
    },
    { 
        label: 'Match Acadêmico & Adoção', 
        href: '/ferramentas/match', 
        icon: 'person_search', 
        color: 'text-brand-yellow', 
        desc: 'Adoção de calouros por veteranos e cartas de interesse em IC',
        category: 'Ferramentas Acadêmicas',
        keywords: ['match', 'academico', 'adocao', 'veterano', 'bixo', 'calouro', 'orientador', 'mentoria', 'ic', 'iniciacao'] 
    },

    // Iniciativas & Extensão
    { 
        label: 'Show de Física do IFUSP', 
        href: '/iniciativas/show-da-fisica', 
        icon: 'bolt', 
        color: 'text-brand-red', 
        desc: 'Espetáculo lúdico de experimentos, sessões para escolas e público geral',
        category: 'Iniciativas de Extensão',
        keywords: ['show', 'fisica', 'show da fisica', 'show de fisica', 'demonstracoes', 'experimentos', 'ludico', 'bobina', 'tesla', 'escolas', 'visita'] 
    },
    { 
        label: 'Monte seu Show da Física', 
        href: '/iniciativas/show-da-fisica/monte-seu-show', 
        icon: 'tune', 
        color: 'text-brand-red', 
        desc: 'Personalize o roteiro de experimentos para a sua visita escolar',
        category: 'Iniciativas de Extensão',
        keywords: ['monte seu show', 'personalizar', 'roteiro', 'selecionar', 'experimentos', 'agendamento'] 
    },

    // Como Ingressar & Visitas
    { 
        label: 'Como Ingressar no IFUSP', 
        href: '/ingresso', 
        icon: 'school', 
        color: 'text-brand-blue', 
        desc: 'Guia completo para vestibulandos: FUVEST, ENEM-USP e Provão Paulista',
        category: 'Como Ingressar',
        keywords: ['ingresso', 'como ingressar', 'vestibular', 'fuvest', 'enem', 'provao paulista', 'olimpiadas', 'vagas', 'curioso'] 
    },
    { 
        label: 'Visitas Escolares & Extensão', 
        href: '/ingresso?tab=visitar', 
        icon: 'explore', 
        color: 'text-brand-blue', 
        desc: 'Agendamento de caravanas, laboratórios e observações astronômicas',
        category: 'Como Ingressar',
        keywords: ['visitas', 'escolas', 'extensao', 'caravanas', 'agendamento', 'laboratorios', 'ceu aberto', 'tours'] 
    },

    // Observatório de Pesquisa
    { 
        label: 'Observatório de Pesquisa & Arena', 
        href: '/arena', 
        icon: 'visibility', 
        color: 'text-brand-red', 
        desc: 'Espaço para docentes e pesquisadores divulgarem linhas ativas e captarem talentos',
        category: 'Observatório',
        keywords: ['observatorio', 'pesquisa', 'arena', 'pesquisador', 'docentes', 'laboratorios', 'linhas de pesquisa'] 
    },
    { 
        label: 'Como o LabDiv Pode Ajudar', 
        href: '/arena?tab=como-ajudar', 
        icon: 'lightbulb', 
        color: 'text-brand-yellow', 
        desc: 'Parcerias, identidade visual, módulos interativos e aceleração de laboratórios',
        category: 'Observatório',
        keywords: ['como o labdiv ajuda', 'parcerias', 'apoio', 'consultoria', 'divulgacao cientifica', 'aceleracao', 'labdiv'] 
    },
    { 
        label: 'Desafios Científicos Ativos', 
        href: '/arena?tab=challenges', 
        icon: 'emoji_events', 
        color: 'text-brand-yellow', 
        desc: 'Desafios propostos pela comunidade científica e oportunidades',
        category: 'Observatório',
        keywords: ['desafios', 'arena', 'competicao', 'propostas', 'premiacao', 'desafios ativos'] 
    },

    // Lab Pessoal & Interações
    { 
        label: 'Meu Laboratório Pessoal', 
        href: '/lab', 
        icon: 'science', 
        color: 'text-brand-blue-accent', 
        desc: 'Seu perfil no HUB: XP, nível, conquistas, hobbies e publicações',
        category: 'Pessoal',
        keywords: ['lab', 'meu laboratorio', 'laboratorio pessoal', 'perfil', 'xp', 'nivel', 'hobbies', 'apelido', 'minhas publicacoes'] 
    },
    { 
        label: 'Central de Interações', 
        href: '/interacao', 
        icon: 'hub', 
        color: 'text-brand-blue', 
        desc: 'Emaranhamento, perguntas da comunidade e conexões',
        category: 'Interações',
        keywords: ['interacao', 'interacoes', 'emaranhamento', 'mensagens', 'perguntas', 'chat', 'duvidas'] 
    },

    // Eixo Informativo & Comunidade
    { 
        label: 'GCIF (Grande Colisor do IF)', 
        href: '/gcif', 
        icon: 'newspaper', 
        color: 'text-brand-red', 
        desc: 'Oportunidades, notícias oficiais, editais e eventos do instituto',
        category: 'Informativo',
        keywords: ['gcif', 'grande colisor', 'informativo', 'noticias', 'oportunidades', 'instituto', 'mural'] 
    },
    { 
        label: 'Mural da Comunidade (Social)', 
        href: '/', 
        icon: 'forum', 
        color: 'text-brand-blue', 
        desc: 'Feed principal da comunidade LabDiv: publicações, discussões e mídia',
        category: 'Social',
        keywords: ['social', 'mural', 'feed', 'comunidade', 'publicacoes', 'home'] 
    },
    { 
        label: 'Galeria de Arte Científica', 
        href: '/?tab=artes', 
        icon: 'palette', 
        color: 'text-brand-yellow', 
        desc: 'Ilustrações, fotografias, infográficos e arte científica produzida no IFUSP',
        category: 'Social',
        keywords: ['arte', 'artes', 'ilustracao', 'design', 'galeria', 'visual', 'desenho'] 
    },
    { 
        label: 'Logs do Sistema LabDiv', 
        href: '/?tab=logs', 
        icon: 'terminal', 
        color: 'text-brand-red', 
        desc: 'Changelog, notas de versão e melhorias contínuas da plataforma',
        category: 'Social',
        keywords: ['logs', 'novidades', 'notas de versao', 'atualizacoes', 'sistema', 'changelog'] 
    },
    { 
        label: 'Arquivo do HUB', 
        href: '/arquivo', 
        icon: 'inventory_2', 
        color: 'text-brand-blue-accent', 
        desc: 'Acervo e repositório de trabalhos e submissões da comunidade',
        category: 'Social',
        keywords: ['arquivo', 'repositorio', 'acervo', 'pesquisa de trabalhos', 'historico'] 
    },
];

interface SearchOverlayProps {
    isOpen: boolean;
    onClose: () => void;
}

interface SubmissionResult {
    id: string;
    title: string;
    category?: string;
}

export function SearchOverlay({ isOpen, onClose }: SearchOverlayProps) {
    const [query, setQuery] = useState('');
    const [dbResults, setDbResults] = useState<SubmissionResult[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const inputRef = useRef<HTMLInputElement>(null);
    const router = useRouter();

    // Focus input when overlay opens
    useEffect(() => {
        if (isOpen) {
            setTimeout(() => inputRef.current?.focus(), 100);
            setQuery('');
            setDbResults([]);
        }
    }, [isOpen]);

    // Close on Escape
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'Escape') onClose();
        };
        if (isOpen) {
            document.addEventListener('keydown', handleKeyDown);
            return () => document.removeEventListener('keydown', handleKeyDown);
        }
    }, [isOpen, onClose]);

    // Debounced Supabase search
    const searchDatabase = useCallback(async (searchTerm: string) => {
        const cleanTerm = searchTerm.trim();
        if (cleanTerm.length < 2) {
            setDbResults([]);
            return;
        }
        setIsLoading(true);
        try {
            const { data } = await supabase
                .from('submissions')
                .select('id, title, category')
                .eq('status', 'aprovado')
                .ilike('title', `%${cleanTerm}%`)
                .limit(8);
            setDbResults((data as SubmissionResult[]) || []);
        } catch {
            setDbResults([]);
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        const timer = setTimeout(() => searchDatabase(query), 350);
        return () => clearTimeout(timer);
    }, [query, searchDatabase]);

    // Filter navigation routes with normalization
    const qNorm = normalizeSearchText(query);
    const filteredNav = qNorm === ''
        ? navRoutes
        : navRoutes.filter(r => {
            const labelMatch = normalizeSearchText(r.label).includes(qNorm);
            const descMatch = normalizeSearchText(r.desc).includes(qNorm);
            const categoryMatch = normalizeSearchText(r.category).includes(qNorm);
            const kwMatch = r.keywords?.some(kw => normalizeSearchText(kw).includes(qNorm));
            return labelMatch || descMatch || categoryMatch || kwMatch;
        });

    // Deep wiki search (title + description + keywords + body content) with normalization
    const filteredWiki = qNorm === ''
        ? []
        : wikiEntries.filter(w => {
            const titleMatch = normalizeSearchText(w.title).includes(qNorm);
            const descMatch = normalizeSearchText(w.desc).includes(qNorm);
            const kwMatch = w.keywords.some(kw => normalizeSearchText(kw).includes(qNorm));
            const contentMatch = normalizeSearchText(w.content).includes(qNorm);
            return titleMatch || descMatch || kwMatch || contentMatch;
        });

    // Disciplinas & Matrizes Curriculares (JúpiterWeb)
    const filteredDisciplines = qNorm.length < 2
        ? []
        : Object.values(disciplinesData).filter(d => {
            const codeMatch = normalizeSearchText(d.codigo).includes(qNorm);
            const nameMatch = normalizeSearchText(d.nome).includes(qNorm);
            const deptMatch = normalizeSearchText(d.departamento || '').includes(qNorm);
            const unidadeMatch = normalizeSearchText(d.unidade).includes(qNorm);
            const ementaMatch = normalizeSearchText(d.ementa).includes(qNorm);
            return codeMatch || nameMatch || deptMatch || unidadeMatch || ementaMatch;
        }).slice(0, 6);

    // Extract a snippet around the matched term with highlight
    const getContentSnippet = (content: string, searchTerm: string): React.ReactNode | null => {
        const lowerContent = content.toLowerCase();
        const lowerSearch = searchTerm.toLowerCase();
        const idx = lowerContent.indexOf(lowerSearch);
        if (idx === -1) return null;

        // Extract a window around the match
        const snippetRadius = 40;
        const start = Math.max(0, idx - snippetRadius);
        const end = Math.min(content.length, idx + lowerSearch.length + snippetRadius);
        
        // Find word boundaries to avoid cutting words
        let snippetStart = start;
        if (start > 0) {
            const spaceIdx = content.indexOf(' ', start);
            snippetStart = spaceIdx !== -1 && spaceIdx < idx ? spaceIdx + 1 : start;
        }
        let snippetEnd = end;
        if (end < content.length) {
            const spaceIdx = content.lastIndexOf(' ', end);
            snippetEnd = spaceIdx > idx + lowerSearch.length ? spaceIdx : end;
        }

        const before = content.slice(snippetStart, idx);
        const match = content.slice(idx, idx + lowerSearch.length);
        const after = content.slice(idx + lowerSearch.length, snippetEnd);

        return (
            <span className="text-[10px] text-gray-500 leading-snug">
                {snippetStart > 0 && '…'}
                {before}
                <mark className="bg-brand-blue/30 text-brand-blue font-bold rounded px-0.5">{match}</mark>
                {after}
                {snippetEnd < content.length && '…'}
            </span>
        );
    };

    if (!isOpen) return null;

    const handleNavigate = (href: string, overrideQuery?: string) => {
        onClose();
        const searchTerm = overrideQuery || query.trim();
        const finalHref = searchTerm && href.startsWith('/wiki/') 
            ? `${href}?hl=${encodeURIComponent(searchTerm)}` 
            : href;
        router.push(finalHref);
    };

    const hasResults = filteredNav.length > 0 || filteredWiki.length > 0 || dbResults.length > 0;

    return (
        <>
            {/* Backdrop */}
            <div
                className="fixed inset-0 bg-background-dark/60 backdrop-blur-sm z-[9998] animate-in fade-in duration-200"
                onClick={onClose}
            />

            {/* Overlay Panel */}
            <div className="fixed inset-x-0 top-0 z-[9999] flex justify-center pt-[72px] px-4 pointer-events-none">
                <div
                    className="w-full max-w-[640px] bg-card-dark border border-white/10 rounded-2xl shadow-2xl overflow-hidden pointer-events-auto animate-in slide-in-from-top-4 fade-in duration-300"
                    onClick={(e) => e.stopPropagation()}
                >
                    {/* Search Input */}
                    <div className="flex items-center gap-3 px-5 py-4 border-b border-white/10">
                        <span className="material-symbols-outlined text-brand-blue text-[22px]">search</span>
                        <input
                            ref={inputRef}
                            type="text"
                            placeholder="Buscar páginas, artigos da Wiki, conteúdo..."
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            className="flex-1 bg-transparent text-white text-sm font-medium placeholder:text-gray-500 outline-none"
                        />
                        {query && (
                            <button onClick={() => setQuery('')} className="text-gray-500 hover:text-white transition-colors">
                                <span className="material-symbols-outlined text-[18px]">close</span>
                            </button>
                        )}
                        <kbd className="hidden sm:flex items-center gap-1 px-2 py-0.5 bg-white/5 border border-white/10 rounded-md text-[10px] text-gray-400 font-mono">
                            ESC
                        </kbd>
                    </div>

                    {/* Results Container */}
                    <div className="max-h-[60vh] overflow-y-auto">
                        {/* Loading State */}
                        {isLoading && (
                            <div className="px-5 py-3 flex items-center gap-3 text-gray-400 text-xs font-bold uppercase tracking-widest border-b border-white/5">
                                <span className="material-symbols-outlined animate-spin text-brand-yellow text-[16px]">progress_activity</span>
                                Buscando conteúdo...
                            </div>
                        )}

                        {/* Section 1: Navegação Rápida */}
                        {filteredNav.length > 0 && (
                            <div className="px-3 pt-3 pb-1">
                                <h3 className="px-2 mb-2 text-[10px] font-black uppercase text-gray-500 tracking-[0.2em]">
                                    {query === '' ? '⚡ Navegação Rápida' : `🔗 Páginas (${filteredNav.length})`}
                                </h3>
                                <div className="flex flex-col">
                                    {filteredNav.map((route, idx) => (
                                        <button
                                            key={idx}
                                            onClick={() => handleNavigate(route.href)}
                                            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5 active:bg-white/10 transition-all text-left group"
                                        >
                                            <div className={`size-8 shrink-0 rounded-lg bg-white/5 flex items-center justify-center ${route.color}`}>
                                                <span className="material-symbols-outlined text-[18px] group-hover:scale-110 transition-transform">{route.icon}</span>
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <span className="text-sm font-bold text-gray-200 group-hover:text-white transition-colors block truncate">{route.label}</span>
                                                <span className="text-[11px] text-gray-500 block truncate">{route.desc}</span>
                                            </div>
                                            <span className="material-symbols-outlined text-gray-600 text-[16px] group-hover:text-gray-400 transition-colors">arrow_forward</span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Section 2: Wiki Articles (Deep Search) */}
                        {filteredWiki.length > 0 && (
                            <div className="px-3 pt-3 pb-1 border-t border-white/5">
                                <h3 className="px-2 mb-2 text-[10px] font-black uppercase text-gray-500 tracking-[0.2em]">
                                    📚 Wiki do Instituto ({filteredWiki.length})
                                </h3>
                                <div className="flex flex-col">
                                    {filteredWiki.map((wiki, idx) => (
                                        <button
                                            key={idx}
                                            onClick={() => handleNavigate(wiki.href)}
                                            className="w-full flex items-start gap-3 px-3 py-2.5 rounded-xl hover:bg-brand-yellow/5 active:bg-brand-yellow/10 transition-all text-left group"
                                        >
                                            <div className="size-8 shrink-0 rounded-lg bg-brand-yellow/10 flex items-center justify-center text-brand-yellow mt-0.5">
                                                <span className="material-symbols-outlined text-[18px]">menu_book</span>
                                            </div>
                                            <div className="flex-1 min-w-0 overflow-hidden">
                                                <span className="text-sm font-bold text-gray-200 group-hover:text-brand-yellow transition-colors block truncate">{wiki.title}</span>
                                                <span className="text-[11px] text-gray-500 block truncate">{wiki.desc}</span>
                                                {/* Content snippet with highlighted match */}
                                                {normalizeSearchText(wiki.content).includes(qNorm) && (
                                                    <div className="mt-1.5 flex items-start gap-1.5 bg-brand-yellow/5 rounded-lg px-2.5 py-2 border border-brand-yellow/10">
                                                        <span className="material-symbols-outlined text-brand-yellow/60 text-[14px] mt-px shrink-0">format_quote</span>
                                                        {getContentSnippet(wiki.content, query)}
                                                    </div>
                                                )}
                                            </div>
                                            <span className="material-symbols-outlined text-gray-600 text-[16px] group-hover:text-brand-yellow transition-colors mt-1">arrow_forward</span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Section 2.5: Disciplinas & Matrizes (JúpiterWeb) */}
                        {filteredDisciplines.length > 0 && (
                            <div className="px-3 pt-3 pb-1 border-t border-white/5">
                                <h3 className="px-2 mb-2 text-[10px] font-black uppercase text-brand-yellow tracking-[0.2em] flex items-center justify-between">
                                    <span>🔬 Disciplinas & JúpiterWeb ({filteredDisciplines.length})</span>
                                    <span className="text-[9px] font-mono font-normal text-gray-500 lowercase">abrir ementa</span>
                                </h3>
                                <div className="flex flex-col">
                                    {filteredDisciplines.map((disc, idx) => (
                                        <button
                                            key={idx}
                                            onClick={() => handleNavigate(`/wiki/ifusp?disciplina=${disc.codigo}`)}
                                            className="w-full flex items-center justify-between gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5 active:bg-white/10 transition-all text-left group"
                                        >
                                            <div className="flex items-center gap-3 min-w-0">
                                                <span className="font-mono text-xs font-bold text-brand-blue-accent group-hover:text-brand-yellow bg-black/40 px-2 py-1 rounded-md border border-white/10 shrink-0">
                                                    {disc.codigo}
                                                </span>
                                                <div className="min-w-0 flex-1">
                                                    <span className="text-sm font-bold text-gray-200 group-hover:text-white transition-colors block truncate">
                                                        {disc.nome}
                                                    </span>
                                                    <span className="text-[11px] text-gray-500 block truncate font-open-sans">
                                                        {disc.unidade} {disc.departamento ? `• Depto. ${disc.departamento}` : ''} • {disc.creditosAula} CA {disc.creditosTrabalho > 0 ? `+ ${disc.creditosTrabalho} CT` : ''}
                                                    </span>
                                                </div>
                                            </div>
                                            <span className="material-symbols-outlined text-gray-600 text-[16px] group-hover:text-brand-yellow transition-colors shrink-0">
                                                arrow_forward
                                            </span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Section 3: Database Content (Submissions) */}
                        {dbResults.length > 0 && (
                            <div className="px-3 pt-3 pb-1 border-t border-white/5">
                                <h3 className="px-2 mb-2 text-[10px] font-black uppercase text-gray-500 tracking-[0.2em]">
                                    🧪 Conteúdo da Comunidade ({dbResults.length})
                                </h3>
                                <div className="flex flex-col">
                                    {dbResults.map((item) => (
                                        <button
                                            key={item.id}
                                            onClick={() => handleNavigate(`/particula/${item.id}`)}
                                            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-brand-blue/5 active:bg-brand-blue/10 transition-all text-left group"
                                        >
                                            <div className="size-8 shrink-0 rounded-lg bg-brand-blue/10 flex items-center justify-center text-brand-blue">
                                                <span className="material-symbols-outlined text-[18px]">article</span>
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <span className="text-sm font-medium text-gray-200 group-hover:text-brand-blue transition-colors block truncate">{item.title}</span>
                                                {item.category && (
                                                    <span className="text-[10px] text-gray-600 uppercase tracking-widest font-bold">{item.category}</span>
                                                )}
                                            </div>
                                            <span className="material-symbols-outlined text-gray-600 text-[16px] group-hover:text-brand-blue transition-colors">arrow_forward</span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* No Results */}
                        {query !== '' && !isLoading && !hasResults && (
                            <div className="p-10 flex flex-col items-center justify-center gap-3 text-center">
                                <span className="material-symbols-outlined text-[48px] text-gray-700">search_off</span>
                                <div className="flex flex-col">
                                    <span className="text-sm font-bold text-gray-400">Nenhum resultado para &quot;{query}&quot;</span>
                                    <span className="text-xs text-gray-600 mt-1">Tente buscar por &quot;bolsas&quot;, &quot;calouro&quot; ou &quot;pesquisa&quot;</span>
                                </div>
                            </div>
                        )}

                        {/* Footer Hint */}
                        <div className="px-5 py-3 border-t border-white/5 flex items-center justify-between text-[10px] text-gray-600">
                            <span className="font-bold uppercase tracking-widest">Hub Lab-Div — Busca Global</span>
                            <div className="flex items-center gap-3">
                                <span className="flex items-center gap-1"><kbd className="px-1.5 py-0.5 bg-white/5 rounded font-mono">↑↓</kbd> navegar</span>
                                <span className="flex items-center gap-1"><kbd className="px-1.5 py-0.5 bg-white/5 rounded font-mono">↵</kbd> abrir</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
