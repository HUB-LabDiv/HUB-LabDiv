'use client';

/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */


import React from 'react';
import Link from 'next/link';
import { m, AnimatePresence } from 'framer-motion';
import { Search, ChevronRight, User } from 'lucide-react';
import { Avatar } from "@/components/ui/Avatar";
import { searchProfiles, followUser, unfollowUser, checkIsFollowing, getSidebarTags, getUsersInOrbit } from '@/app/actions/submissions';
import { toast } from 'react-hot-toast';
import { SkeletonProfile } from '@/components/ui/SkeletonProfile';

interface SidebarTag {
    name: string;
    count: number;
}

interface SidebarAuthor {
    id: string;
    name: string;
    handle: string;
    avatar: string | null;
    xp?: number;
    level?: number;
    is_labdiv?: boolean;
}

interface SidebarRightProps {
    tags?: SidebarTag[];
    authors?: SidebarAuthor[];
}

export const SidebarRight = ({ tags: propTags, authors: propAuthors }: SidebarRightProps) => {
    const [tags, setTags] = React.useState<SidebarTag[]>(propTags || []);
    const [initialAuthors, setInitialAuthors] = React.useState<SidebarAuthor[]>(propAuthors || []);

    // Fetch data client-side if not provided via props
    React.useEffect(() => {
        if (!propTags) {
            getSidebarTags().then(data => setTags(data));
        }
        if (!propAuthors) {
            getUsersInOrbit(0).then(data => setInitialAuthors(data));
        }
    }, [propTags, propAuthors]);
    const [page, setPage] = React.useState(0);
    const [activeTab, setActiveTab] = React.useState<'trending' | 'search'>('trending');
    const [searchQuery, setSearchQuery] = React.useState('');
    const [searchResults, setSearchResults] = React.useState<SidebarAuthor[]>([]);
    const [isSearching, setIsSearching] = React.useState(false);
    const [followingIds, setFollowingIds] = React.useState<Set<string>>(new Set());

    const tagsPerPage = 4;
    const totalPages = Math.ceil((tags.length || 1) / tagsPerPage);

    const currentTags = tags.slice(page * tagsPerPage, (page + 1) * tagsPerPage);

    const usersPerPage = 5;
    const [userPage, setUserPage] = React.useState(0);
    const totalUserPages = Math.ceil((initialAuthors.length || 1) / usersPerPage);
    const currentUserList = activeTab === 'search' ? searchResults : initialAuthors.slice(userPage * usersPerPage, (userPage + 1) * usersPerPage);

    const handleNextUserPage = () => {
        setUserPage((prev) => (prev + 1) % totalUserPages);
    };

    // Unified check for following status
    React.useEffect(() => {
        const checkFollows = async (authors: SidebarAuthor[]) => {
            if (authors.length === 0) return;
            const followStates = await Promise.all(
                authors.map(async (author) => {
                    const isFollowing = await checkIsFollowing(author.id);
                    return { id: author.id, isFollowing };
                })
            );
            setFollowingIds(prev => {
                const next = new Set(prev);
                followStates.forEach(f => {
                    if (f.isFollowing) next.add(f.id);
                    else next.delete(f.id);
                });
                return next;
            });
        };

        checkFollows(initialAuthors);
    }, [initialAuthors]);

    React.useEffect(() => {
        const checkFollows = async (authors: SidebarAuthor[]) => {
            if (authors.length === 0) return;
            const followStates = await Promise.all(
                authors.map(async (author) => {
                    const isFollowing = await checkIsFollowing(author.id);
                    return { id: author.id, isFollowing };
                })
            );
            setFollowingIds(prev => {
                const next = new Set(prev);
                followStates.forEach(f => {
                    if (f.isFollowing) next.add(f.id);
                    else next.delete(f.id);
                });
                return next;
            });
        };

        checkFollows(searchResults);
    }, [searchResults]);

    // Fast Search
    React.useEffect(() => {
        const timer = setTimeout(async () => {
            if (searchQuery.length >= 2) {
                setIsSearching(true);
                try {
                    const results = await searchProfiles(searchQuery);
                    setSearchResults(results as SidebarAuthor[]);
                } catch (err) {
                    console.error(err);
                } finally {
                    setIsSearching(false);
                }
            } else {
                setSearchResults([]);
            }
        }, 300);
        return () => clearTimeout(timer);
    }, [searchQuery]);

    const handleFollowToggle = async (id: string) => {
        const isCurrentlyFollowing = followingIds.has(id);

        // Optimistic update
        const newIds = new Set(followingIds);
        if (isCurrentlyFollowing) newIds.delete(id);
        else newIds.add(id);
        setFollowingIds(newIds);

        const res = isCurrentlyFollowing ? await unfollowUser(id) : await followUser(id);
        if (!res.success) {
            const errorMessage = res.error === 'Não autorizado' 
                ? "Faça login no HUB para seguir usuários!" 
                : (res.error || "Erro na conexão");
            toast.error(errorMessage);
            // Revert on error using the previous state (followingIds)
            setFollowingIds(followingIds);
        } else {
            toast.success(isCurrentlyFollowing ? "Conexão encerrada" : "Conexão estabelecida!");
        }
    };

    const handleNextPage = () => {
        setPage((prev) => (prev + 1) % totalPages);
    };

    return (
        <div className="flex-1 min-h-0 flex flex-col gap-6 mt-6">

            {/* ISÓTOPOS EM ÓRBITA */}
            <div className="bg-white dark:bg-card-dark rounded-3xl p-5 border border-gray-200 dark:border-gray-800 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-sm font-black uppercase tracking-widest text-brand-blue">Isótopos em Órbita</h2>
                    <div className="flex gap-1">
                        {Array.from({ length: totalPages }).map((_, i) => (
                            <div key={i} className={`w-1.5 h-1.5 rounded-full transition-all ${page === i ? 'bg-brand-blue w-4 shadow-[0_0_8px_rgba(59,130,246,0.5)]' : 'bg-gray-300 dark:bg-gray-700'}`} />
                        ))}
                    </div>
                </div>

                <div className="relative min-h-[160px]">
                    <AnimatePresence mode="wait">
                        <m.div
                            key={page}
                            initial={{ x: 20, opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            exit={{ x: -20, opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="flex flex-col gap-4"
                        >
                            {currentTags.length > 0 ? currentTags.map((tag) => (
                                <Link
                                    key={tag.name}
                                    href={`/?category=${tag.name}`}
                                    className="group flex flex-col hover:opacity-80 transition-opacity"
                                >
                                    <span className={`text-xs font-black transition-colors ${tag.name.length % 3 === 0 ? 'text-brand-blue' :
                                        tag.name.length % 3 === 1 ? 'text-brand-yellow' :
                                            'text-brand-red'
                                        }`}>#{tag.name}</span>
                                    <span className="text-[10px] text-gray-500 uppercase tracking-wide font-medium">{tag.count} contribuições</span>
                                </Link>
                            )) : (
                                <span className="text-xs text-gray-500 italic">Nenhum isótopo detectado...</span>
                            )}
                        </m.div>
                    </AnimatePresence>
                </div>

                <button
                    onClick={handleNextPage}
                    className="mt-4 text-xs font-bold text-brand-yellow hover:underline flex items-center gap-1 group"
                >
                    Explorar mais isótopos
                    <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </button>
            </div>

            <div className="bg-white dark:bg-card-dark rounded-3xl pb-5 border border-gray-200 dark:border-gray-800 shadow-sm flex-1 min-h-0 flex flex-col overflow-hidden">
                <div className="flex shrink-0 border-b border-gray-100 dark:border-gray-800">
                    <button
                        onClick={() => setActiveTab('trending')}
                        className={`flex-1 py-4 text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'trending' ? 'text-brand-blue border-b-2 border-brand-blue bg-brand-blue/5' : 'text-gray-400 hover:text-gray-600'}`}
                    >
                        Principais
                    </button>
                    <button
                        onClick={() => setActiveTab('search')}
                        className={`flex-1 py-4 text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'search' ? 'text-brand-red border-b-2 border-brand-red bg-brand-red/5' : 'text-gray-400 hover:text-gray-600'}`}
                    >
                        Buscar
                    </button>
                </div>

                <div className="p-5 flex-1 min-h-0 flex flex-col">
                    <div className="flex items-center justify-between mb-4 shrink-0">
                        <h2 className="text-xs font-black uppercase tracking-widest text-gray-900 dark:text-white">Usuários em Órbita</h2>
                        {activeTab === 'trending' && (
                            <div className="flex gap-1">
                                {Array.from({ length: totalUserPages }).map((_, i) => (
                                    <div key={i} className={`w-1.5 h-1.5 rounded-full transition-all ${userPage === i ? 'bg-brand-red w-4 shadow-[0_0_8px_rgba(239,68,68,0.5)]' : 'bg-gray-300 dark:bg-gray-700'}`} />
                                ))}
                            </div>
                        )}
                    </div>

                    {activeTab === 'search' && (
                        <div className="relative mb-4 shrink-0 animate-in fade-in slide-in-from-top-2 duration-300">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <input
                                type="text"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                placeholder="Nome ou @user..."
                                className="w-full bg-gray-50 dark:bg-card-dark border border-gray-200 dark:border-transparent rounded-xl py-2 pl-9 pr-4 text-xs font-medium outline-none focus:border-brand-blue transition-all"
                            />
                            {isSearching && (
                                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                                    <div className="w-3 h-3 border-2 border-brand-blue border-t-transparent rounded-full animate-spin" />
                                </div>
                            )}
                        </div>
                    )}

                    <div className="flex-1 min-h-0 overflow-y-auto hidden-scrollbar pr-1 flex flex-col gap-4">
                        {initialAuthors.length === 0 && activeTab === 'trending' ? (
                            <>
                                <SkeletonProfile compact />
                                <SkeletonProfile compact />
                                <SkeletonProfile compact />
                                <SkeletonProfile compact />
                                <SkeletonProfile compact />
                            </>
                        ) : currentUserList.length > 0 ?
                            currentUserList.map((user) => {
                                const isFollowing = followingIds.has(user.id);
                                return (
                                    <div key={`${activeTab}-${user.id}`} className="flex items-center justify-between gap-3 animate-in fade-in duration-300">
                                        <Link href={`/lab?user=${user.id}`} className="flex items-center gap-3 overflow-hidden cursor-pointer hover:opacity-80 transition-opacity flex-1">
                                            <Avatar
                                                src={user.avatar}
                                                name={user.name}
                                                size="md"
                                                customSize="size-10"
                                                xp={user.xp}
                                                level={user.level}
                                                isLabDiv={user.is_labdiv}
                                            />
                                            <div className="flex flex-col overflow-hidden">
                                                <span className="text-xs font-bold text-gray-900 dark:text-white truncate max-w-[130px]" title={user.name}>{user.name}</span>
                                            </div>
                                        </Link>

                                        <div className="flex gap-1 shrink-0">
                                            <button
                                                onClick={() => handleFollowToggle(user.id)}
                                                className={`px-3 py-1.5 text-[10px] font-black rounded-full transition-all ${isFollowing ? 'bg-gray-100 dark:bg-white/10 text-gray-500 hover:bg-brand-red/10 hover:text-brand-red' :
                                                    (user.name.split('').reduce((a, b) => a + b.charCodeAt(0), 0)) % 3 === 0 ? 'bg-brand-blue text-white hover:scale-105 shadow-lg shadow-brand-blue/10' :
                                                        (user.name.split('').reduce((a, b) => a + b.charCodeAt(0), 0)) % 3 === 1 ? 'bg-brand-yellow text-gray-900 hover:scale-105 shadow-lg shadow-brand-yellow/10' :
                                                            'bg-brand-red text-white hover:scale-105 shadow-lg shadow-brand-red/10'
                                                    }`}
                                            >
                                                {isFollowing ? 'Seguindo' : 'Seguir'}
                                            </button>


                                        </div>
                                    </div>
                                );
                            }) : (
                                <span className="text-xs text-gray-500 italic">
                                    {activeTab === 'search' && searchQuery.length < 2 ? 'Digite 2 caracteres para buscar...' : 'Nenhum usuário detectado.'}
                                </span>
                            )
                        }
                    </div>

                    {activeTab === 'trending' && totalUserPages > 1 && (
                        <button
                            onClick={handleNextUserPage}
                            className="mt-4 text-xs font-bold text-brand-red hover:underline flex items-center gap-1 group"
                        >
                            Explorar mais usuários
                            <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                        </button>
                    )}
                </div>
            </div>

            {/* Footer Links */}
            <div className="px-5 py-2 flex flex-wrap gap-x-4 gap-y-1 text-[10px] text-gray-400 font-medium">
                <Link href="/privacy" className="hover:underline">Privacidade</Link>
                <Link href="/terms" className="hover:underline">Termos</Link>
                <Link href="/delete-account" className="hover:underline">Exclusão de Conta</Link>
                <Link href="/transparencia" className="hover:underline">Transparência</Link>
                <span>© 2026 IFUSP Lab-Div - Hub de Comunicação Científica</span>
            </div>
        </div>
    );
};
