'use client';

/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */


import React, { useState, useEffect } from 'react';
import { m, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { fetchNotifications, markNotificationAsRead, getUnreadCount, markAllNotificationsAsRead } from '@/app/actions/notifications';
import { supabase } from '@/lib/supabase';
import { useHistoryBack } from '@/hooks/useHistoryBack';
import { toast } from 'react-hot-toast';

export const NotificationBell = ({ userId }: { userId: string | undefined }) => {
    const [notifications, setNotifications] = useState<any[]>([]);
    const [unreadCount, setUnreadCount] = useState(0);
    const [isOpen, setIsOpen] = useState(false);
    const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());

    // [B14] Support hardware back button to close the menu
    useHistoryBack(isOpen, () => setIsOpen(false));

    useEffect(() => {
        if (!userId) {
            setNotifications([]);
            setUnreadCount(0);
            return;
        }

        // Initial fetch
        const load = async () => {
            try {
                const [list, count] = await Promise.all([
                    fetchNotifications(userId),
                    getUnreadCount(userId)
                ]);
                setNotifications(list);
                setUnreadCount(count);
            } catch (err) {
                console.error('Error loading notifications:', err);
            }
        };
        load();

        // Realtime subscription
        const channel = supabase
            .channel(`notifications-${userId}`)
            .on('postgres_changes', {
                event: 'INSERT',
                schema: 'public',
                table: 'notifications',
                filter: `user_id=eq.${userId}`
            }, async (payload) => {
                setNotifications(prev => [payload.new, ...prev]);
                setUnreadCount(prev => prev + 1);
            })
            .subscribe();

        return () => { supabase.removeChannel(channel); };
    }, [userId]);

    const handleMarkAsRead = async (id: string) => {
        if (!userId) return;
        
        const notif = notifications.find(n => n.id === id);
        if (notif && notif.is_read) return;

        // Optimistic update to prevent delays
        setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
        setUnreadCount(prev => Math.max(0, prev - 1));

        // Fire Server Action
        await markNotificationAsRead(id);
    };

    const handleMarkAllAsRead = async () => {
        if (!userId || unreadCount === 0) return;
        
        const res = await markAllNotificationsAsRead(userId);
        if (res.success) {
            setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
            setUnreadCount(0);
            toast.success('Todas as notificações foram lidas!');
        } else {
            toast.error('Erro ao marcar notificações');
        }
    };

    const toggleExpand = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        setExpandedIds(prev => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id);
            else next.add(id);
            return next;
        });
    };

    return (
        <div className="relative">
            <button
                data-tour="notifications-bell"
                onClick={() => setIsOpen(!isOpen)}
                className="relative p-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-all"
                aria-label="Notificações"
            >
                <span className="material-symbols-outlined text-[26px]">notifications</span>
                {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 size-5 bg-brand-red text-white text-[10px] font-black rounded-full flex items-center justify-center border-2 border-white dark:border-background-dark">
                        {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                )}
            </button>

            <AnimatePresence>
                {isOpen && (
                    <m.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute right-0 mt-2 w-80 bg-white dark:bg-[#1E1E1E] rounded-3xl shadow-2xl border border-gray-100 dark:border-gray-800 overflow-hidden z-[100] origin-top-right"
                    >
                        {!userId ? (
                            // [I01] Sininho Gatekeeper - Guest State
                            <div className="p-8 text-center space-y-4">
                                <div className="w-16 h-16 bg-brand-blue/10 text-brand-blue rounded-full flex items-center justify-center mx-auto mb-2">
                                    <span className="material-symbols-outlined text-3xl">login</span>
                                </div>
                                <h3 className="text-sm font-bold text-gray-900 dark:text-white">Fique por dentro!</h3>
                                <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                                    Faça login para receber notificações sobre likes, comentários e aprovações no acervo.
                                </p>
                                <Link
                                    href="/login"
                                    className="block w-full py-3 bg-brand-blue text-white text-xs font-black rounded-2xl hover:bg-blue-700 transition-all shadow-md active:scale-95"
                                >
                                    ENTRAR NO LAB-DIV
                                </Link>
                            </div>
                        ) : (
                            // Logged In State
                            <>
                                <div className="p-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between bg-gray-50/50 dark:bg-gray-900/50">
                                    <span className="text-xs font-black uppercase tracking-widest text-gray-500">Notificações</span>
                                    <button 
                                        onClick={handleMarkAllAsRead}
                                        disabled={unreadCount === 0}
                                        className="text-[10px] font-bold text-brand-blue hover:underline disabled:opacity-30 disabled:no-underline"
                                    >
                                        Marcar todas como lidas
                                    </button>
                                </div>

                                <div className="max-h-[32rem] overflow-y-auto no-scrollbar">
                                    {notifications.length === 0 ? (
                                        <div className="p-12 text-center text-gray-400">
                                            <span className="material-symbols-outlined text-4xl opacity-20 block mb-2">notifications_off</span>
                                            <p className="text-xs font-medium">Nada por aqui ainda.</p>
                                        </div>
                                    ) : (
                                        notifications.map(notif => {
                                            const isExpanded = expandedIds.has(notif.id);
                                            const canExpand = notif.message?.length > 60;

                                            return (
                                                <div
                                                    key={notif.id}
                                                    onClick={() => handleMarkAsRead(notif.id)}
                                                    className={`flex gap-3 p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors border-b border-gray-50 dark:border-gray-800/50 relative cursor-pointer ${!notif.is_read ? 'bg-brand-blue/5' : ''}`}
                                                >
                                                    <div className={`size-10 rounded-full flex items-center justify-center flex-shrink-0 ${notif.type === 'atomic' ? 'bg-brand-blue/20 text-brand-blue shadow-[0_0_10px_rgba(59,130,246,0.2)]' : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
                                                        }`}>
                                                        <span className="material-symbols-outlined filled">
                                                            {notif.type === 'atomic' ? 'offline_bolt' : 'notifications'}
                                                        </span>
                                                    </div>
                                                    <div className="flex-1 min-w-0">
                                                        <p className="text-xs font-bold text-gray-900 dark:text-white leading-tight mb-0.5">{notif.title}</p>
                                                        <p className={`text-[11px] text-gray-500 leading-snug whitespace-pre-wrap ${isExpanded ? '' : 'line-clamp-2'}`}>
                                                            {notif.message}
                                                        </p>
                                                        
                                                        {canExpand && (
                                                            <button 
                                                                onClick={(e) => toggleExpand(e, notif.id)}
                                                                className="text-[9px] font-black text-brand-blue uppercase tracking-tighter mt-1 hover:underline"
                                                            >
                                                                {isExpanded ? 'Ver Menos' : 'Ver Mais'}
                                                            </button>
                                                        )}

                                                        <div className="flex items-center justify-between mt-2">
                                                            <p className="text-[9px] text-gray-400 font-medium">{new Date(notif.created_at).toLocaleDateString()}</p>
                                                            {notif.link && notif.link !== '#' && (
                                                                <Link 
                                                                    href={notif.link}
                                                                    onClick={(e) => {
                                                                        e.stopPropagation();
                                                                        handleMarkAsRead(notif.id);
                                                                        setIsOpen(false);
                                                                    }}
                                                                    className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-brand-blue text-white hover:bg-brand-blue transition-all shadow-sm"
                                                                >
                                                                    <span className="material-symbols-outlined text-[10px] font-bold">link</span>
                                                                    <span className="text-[8px] font-black uppercase tracking-tighter">LINK</span>
                                                                </Link>
                                                            )}
                                                        </div>
                                                    </div>
                                                    {!notif.is_read && (
                                                        <div className="size-1.5 bg-brand-blue rounded-full absolute top-4 right-4 animate-pulse shadow-[0_0_8px_rgba(59,130,246,0.6)]" />
                                                    )}
                                                </div>
                                            );
                                        })
                                    )}
                                </div>
                            </>
                        )}
                    </m.div>
                )}
            </AnimatePresence>
        </div>
    );
};
