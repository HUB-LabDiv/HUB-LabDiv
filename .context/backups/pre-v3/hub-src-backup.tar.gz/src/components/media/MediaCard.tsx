'use client';

/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */


import React, { useState, useCallback, useRef, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import {
    Eye,
    ExternalLink,
    ChevronLeft,
    ChevronRight,
    Layers,
    Play,
    Pencil,
    Rocket,
    Download,
    Star,
    Clock,
    ImageOff,
    Atom,
    Flag,
    MoreHorizontal,
    Edit3,
    Trash2,
    RotateCcw
} from 'lucide-react';
import dynamic from 'next/dynamic';

const ScientificContent = dynamic(() => import( "@/components/shared/ScientificContent"), {
    loading: () => <div className="h-20 w-full animate-pulse bg-gray-100 dark:bg-gray-800 rounded-lg" />
});

import { Avatar } from "@/components/ui/Avatar";

import { parseMediaUrl, getYoutubeThumbnail, getOptimizedUrl } from '@/lib/media-utils';
import { resolveBackupMediaUrl } from '@/app/actions/media';
const ShareMenu = dynamic(() => import( "@/components/shared/ShareMenu").then(mod => mod.ShareMenu));
import { LocalErrorBoundary } from '@/components/shared/LocalErrorBoundary';
import { m, AnimatePresence } from 'framer-motion';
import { stripMarkdownAndLatex, highlightMatch } from '@/lib/utils';
import { useInView } from 'react-intersection-observer';
import { CardPresenceBadge } from "@/components/ui/CardPresenceBadge";
import { supabase } from '@/lib/supabase';
import { useNavigationStore } from '@/store/useNavigationStore';
import toast from 'react-hot-toast';
const CollectionManager = dynamic(() => import( "@/components/engagement/CollectionManager").then(mod => mod.CollectionManager));
const DownloadModal = dynamic(() => import( "@/components/modals/DownloadModal").then(mod => mod.DownloadModal));
import { MediaReaction } from "@/components/engagement/MediaReaction";
import { PostDTO } from '@/dtos/media';
import { useMediaInteraction } from '@/hooks/useMediaInteraction';
import { useAuth } from '@/providers/AuthProvider';
import { useMemo } from 'react';

export interface MediaCardProps {
    post: PostDTO;
    priority?: boolean;
    isLikedByUser?: boolean;
    isSavedByUser?: boolean;
    highlightQuery?: string;
    setIsSyncing?: (val: boolean) => void;
}

import { CATEGORY_STYLES, DEFAULT_STYLE } from '@/lib/constants';

const KITDIV_LOCAL_COVERS: Record<string, string> = {
    'palestras que inspiram': '/images/kitdiv/palestrasqueinspirao.png',
    'como escrever bons e-mails': '/images/kitdiv/comoescreveremails.png',
    'como escrever emails': '/images/kitdiv/comoescreveremails.png',
    'caderno de dados brilhante': '/images/kitdiv/cadernodedadosbrilhante.png',
    'slides que funcionam': '/images/kitdiv/slides.jpeg',
    'pôsteres impactantes': '/images/kitdiv/posteresimpactantes.jpeg',
    'posteres impactantes': '/images/kitdiv/posteresimpactantes.jpeg',
};

/**
 * V8.0 MediaCard - Hardened & Refactored
 * Implements DTO Enforcement and hook-based logic.
 */
export const MediaCard = React.memo(({ post, priority = false, isLikedByUser = false, isSavedByUser = false, highlightQuery = '', setIsSyncing }: MediaCardProps) => {
    const { user } = useAuth();
    const { openContentReport } = useNavigationStore();
    const userId = user?.id;
    const [currentImageIndex, setCurrentImageIndex] = useState(0);
    const [isHovered, setIsHovered] = useState(false);
    const [showShareMenu, setShowShareMenu] = useState(false);
    const [showCollectionManager, setShowCollectionManager] = useState(false);
    const [showDownloadModal, setShowDownloadModal] = useState(false);
    const [showAtomAnimation, setShowAtomAnimation] = useState(false);
    const [showAuthorMenu, setShowAuthorMenu] = useState(false);

    const isAuthor = userId === post.userId;

    const handleEdit = (e: React.MouseEvent) => {
        e.stopPropagation();
        router.push(`/enviar?editId=${post.id}`);
    };

    const handleDelete = async (e: React.MouseEvent) => {
        e.stopPropagation();
        if(confirm('Tem certeza que deseja apagar permanentemente esta publicação?')) {
            const toastId = toast.loading('Apagando publicação...');
            const { deleteOwnSubmission } = await import('@/app/actions/submissions');
            const res = await deleteOwnSubmission(post.id);
            if (res.error) {
                toast.error(res.error, { id: toastId });
            } else {
                toast.success('Publicação apagada com sucesso!', { id: toastId });
                window.location.reload();
            }
        }
    };

    const handleRevertToDraft = async (e: React.MouseEvent) => {
        e.stopPropagation();
        if(confirm('Tem certeza que deseja mover esta publicação para os rascunhos?')) {
            const toastId = toast.loading('Movendo para rascunhos...');
            const { revertSubmissionToDraft } = await import('@/app/actions/submissions');
            const res = await revertSubmissionToDraft(post.id);
            if (res.error) {
                toast.error(res.error, { id: toastId });
            } else {
                toast.success('Movido para rascunhos!', { id: toastId });
                window.location.reload();
            }
        }
    };

    const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const router = useRouter();
    const query = highlightQuery;
    const { ref: contentRef, inView } = useInView({
        triggerOnce: true,
        rootMargin: '200px 0px',
    });

    const {
        likes,
        liked,
        saves,
        saved,
        handleLike,
        handleSave
    } = useMediaInteraction({
        id: post.id,
        initialLikes: post.likeCount || 0,
        initialSaves: post.saveCount || 0,
        initialLiked: isLikedByUser,
        // (Note: useMediaInteraction hook currently lacks initialSaved param, we will need to update it next)
        userId,
        setIsSyncing
    });

    const handleMouseEnter = () => {
        hoverTimeoutRef.current = setTimeout(() => {
            setIsHovered(true);
        }, 300);
    };

    const handleMouseLeave = () => {
        if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
        setIsHovered(false);
    };

    const handleDoubleClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        e.preventDefault();

        // Trigger Adam animation
        setShowAtomAnimation(true);
        setTimeout(() => setShowAtomAnimation(false), 1000);

        // Give like if not already liked
        if (!liked) {
            handleLike();
        }
    };



    const urls = useMemo(() => parseMediaUrl(post.mediaUrl), [post.mediaUrl]);
    const hasMultipleImages = useMemo(() => post.mediaType === 'image' && urls.length > 1, [post.mediaType, urls.length]);
    const sizeModifierStyles = useMemo(() => hasMultipleImages ? "md:min-h-[420px] shadow-lg" : "", [hasMultipleImages]);

    const handleNextImage = useCallback((e: React.MouseEvent) => {
        e.stopPropagation();
        setCurrentImageIndex((prev) => (prev + 1) % urls.length);
    }, [urls.length]);

    const handlePrevImage = useCallback((e: React.MouseEvent) => {
        e.stopPropagation();
        setCurrentImageIndex((prev) => (prev - 1 + urls.length) % urls.length);
    }, [urls.length]);

    const displayUrl = useMemo(() => {
        let url = urls.length > 0 ? urls[currentImageIndex] : '';
        if (post.mediaType === 'pdf' && url.toLowerCase().endsWith('.pdf')) {
            url = url.replace(/\.pdf$/i, '.jpg');
        }
        if (!url && post.title) {
            const cleanTitle = post.title.toLowerCase().trim();
            const kitFallback = KITDIV_LOCAL_COVERS[cleanTitle];
            if (kitFallback) return kitFallback;
        }
        return url;
    }, [urls, currentImageIndex, post.mediaType, post.title]);

    const [hasImageError, setHasImageError] = useState(false);
    const [fallbackBackupUrl, setFallbackBackupUrl] = useState<string | null>(null);

    useEffect(() => {
        setHasImageError(false);
        setFallbackBackupUrl(null);
    }, [displayUrl]);

    const optimizedDisplayUrl = useMemo(() => getOptimizedUrl(displayUrl, 600, 70, post.category, post.mediaType), [displayUrl, post.category, post.mediaType]);
    const activeDisplayUrl = fallbackBackupUrl || optimizedDisplayUrl;

    const handleImageError = useCallback(async () => {
        if (!fallbackBackupUrl && displayUrl && displayUrl.includes('cloudinary.com')) {
            try {
                const res = await resolveBackupMediaUrl(displayUrl);
                if (res.success && res.backupUrl) {
                    setFallbackBackupUrl(res.backupUrl);
                    return;
                }
            } catch {}
        }
        setHasImageError(true);
    }, [displayUrl, fallbackBackupUrl]);

    // Use dynamic category styles
    const categoryStyle = post.category ? (CATEGORY_STYLES[post.category] || DEFAULT_STYLE) : DEFAULT_STYLE;
    const buttonColorClass = `${categoryStyle.bg} ${categoryStyle.text}`;

    return (
        <LocalErrorBoundary>
            <div
                onClick={() => router.push(`/arquivo/${post.id}`)}
            className={`masonry-item group relative flex flex-col overflow-hidden rounded-2xl bg-white dark:bg-card-dark shadow-[0_2px_15px_-3px_rgba(0,0,0,0.07),0_10px_20px_-2px_rgba(0,0,0,0.04)] dark:shadow-sm transition-all hover:shadow-xl cursor-pointer gpu-isolate 
            ${post.isGoldenStandard ? 'golden-frame z-10' : 
              post.isFeatured ? 'border-2 border-brand-yellow/50 animate-premium-glow z-10' : 
              'border border-gray-200 dark:border-gray-800'} ${sizeModifierStyles}`}
        >
            <CardPresenceBadge submissionId={post.id} />

            <AnimatePresence>
                {isHovered && post.description && (post.mediaType === 'text' || post.mediaType === 'pdf') && (
                    <m.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ duration: 0.2 }}
                        className="absolute inset-[4px] top-[48px] bottom-[140px] z-30 p-5 bg-white/95 dark:bg-card-dark/95 backdrop-blur-md border border-gray-100 dark:border-gray-800 rounded-xl shadow-2xl overflow-y-auto no-scrollbar pointer-events-none"
                    >
                        <div className="flex items-center gap-2 mb-3">
                            <Eye className="w-4 h-4 text-brand-blue dark:text-brand-yellow" />
                            <span className="text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400">Prévia Rápida</span>
                        </div>
                        <ScientificContent content={post.description} />
                        <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-white dark:from-card-dark to-transparent"></div>
                    </m.div>
                )}
            </AnimatePresence>

            <div
                onClick={(e) => e.stopPropagation()}
                className="flex items-center justify-between p-4 md:p-6 border-b border-gray-100 dark:border-gray-800 cursor-default"
            >
                <div className="flex items-center gap-2">
                    <Avatar
                        src={post.avatarUrl}
                        name={post.authors}
                        size="sm"
                        className="border-2 border-white dark:border-[#1E1E1E] shadow-sm hover:scale-110 transition-transform duration-300"
                        xp={post.authorXp}
                        level={post.authorLevel}
                        isLabDiv={post.authorIsLabDiv}
                        onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            router.push(`/lab-pessoal/${post.userId}`);
                        }}
                    />
                    <Link
                        href={`/lab-pessoal/${post.userId}`}
                        onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            router.push(`/lab-pessoal/${post.userId}`);
                        }}
                        className="text-xs font-bold text-gray-900 dark:text-gray-100 hover:text-brand-blue transition-colors truncate max-w-[120px] sm:max-w-[180px]"
                    >
                        {post.authors}
                    </Link>
                </div>
                <div className="flex items-center gap-2">
                    {post.category !== 'Arte' && (
                        <div className="hover:scale-105 transition-transform active:scale-95">
                            <Link
                                href={`/arquivo/${post.id}`}
                                onClick={(e) => e.stopPropagation()}
                                className={`inline-flex items-center justify-center gap-1 rounded-lg px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider shadow-md transition-all hover:shadow-lg whitespace-nowrap shrink-0 ${buttonColorClass}`}
                            >
                                <span className="flex items-center gap-1">
                                    Página Completa
                                    <ExternalLink className="w-3 h-3" />
                                </span>
                            </Link>
                        </div>
                    )}
                    
                    {isAuthor && (
                        <div className="relative">
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setShowAuthorMenu(!showAuthorMenu);
                                }}
                                className="p-1.5 rounded-lg text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                            >
                                <MoreHorizontal className="w-4 h-4" />
                            </button>
                            
                            <AnimatePresence>
                                {showAuthorMenu && (
                                    <m.div
                                        initial={{ opacity: 0, scale: 0.95, y: -10 }}
                                        animate={{ opacity: 1, scale: 1, y: 0 }}
                                        exit={{ opacity: 0, scale: 0.95, y: -10 }}
                                        className="absolute right-0 top-full mt-2 w-48 bg-white dark:bg-card-dark border border-gray-100 dark:border-gray-800 rounded-xl shadow-xl z-50 overflow-hidden"
                                    >
                                        <div className="flex flex-col py-1">
                                            <button
                                                onClick={(e) => { setShowAuthorMenu(false); handleEdit(e); }}
                                                className="w-full px-4 py-2 text-left flex items-center gap-2 text-sm font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                                            >
                                                <Edit3 className="w-4 h-4 text-brand-blue" />
                                                Editar
                                            </button>
                                            <button
                                                onClick={(e) => { setShowAuthorMenu(false); handleRevertToDraft(e); }}
                                                className="w-full px-4 py-2 text-left flex items-center gap-2 text-sm font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                                            >
                                                <RotateCcw className="w-4 h-4 text-brand-yellow" />
                                                Voltar p/ Rascunho
                                            </button>
                                            <button
                                                onClick={(e) => { setShowAuthorMenu(false); handleDelete(e); }}
                                                className="w-full px-4 py-2 text-left flex items-center gap-2 text-sm font-bold text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                                Apagar
                                            </button>
                                        </div>
                                    </m.div>
                                )}
                            </AnimatePresence>
                        </div>
                    )}
                </div>
            </div>

            <div
                onClick={(e) => e.stopPropagation()}
                className={`relative w-full overflow-hidden shrink-0 ${post.mediaType === 'video' || !hasMultipleImages ? 'aspect-video' : 'aspect-square'} max-h-[500px] bg-gray-100 dark:bg-gray-800 cursor-default select-none`}
                onMouseEnter={handleMouseEnter}
                onMouseLeave={handleMouseLeave}
                onDoubleClick={handleDoubleClick}
            >
                <AnimatePresence>
                    {showAtomAnimation && (
                        <m.div
                            initial={{ scale: 0.5, opacity: 0, rotate: -20 }}
                            animate={{ scale: [1.2, 1], opacity: 1, rotate: 0 }}
                            exit={{ scale: 0.8, opacity: 0 }}
                            transition={{ duration: 0.4, type: 'spring', bounce: 0.6 }}
                            className="absolute inset-0 z-[100] flex items-center justify-center pointer-events-none drop-shadow-2xl"
                        >
                            <Atom className="w-24 h-24 text-white fill-brand-blue/90 animate-pulse-fast drop-shadow-[0_0_15px_rgba(31,159,207,0.8)]" />
                        </m.div>
                    )}
                </AnimatePresence>

                {post.mediaType === 'video' ? (
                    <Image
                        src={urls.length > 0 ? getYoutubeThumbnail(urls[0]) : "https://images.unsplash.com/photo-1616423640778-28d1b53229bd?auto=format&fit=crop&q=80&w=800"}
                        alt={post.title || "Video Thumbnail"}
                        fill
                        sizes="(max-width: 640px) 100vw, 50vw"
                        className="object-cover opacity-80"
                        priority={priority}
                        fetchPriority={priority ? "high" : "auto"}
                        loading={priority ? "eager" : "lazy"}
                    />
                ) : (post.mediaType === 'text' || post.mediaType === 'zip' || post.mediaType === 'sdocx') && !displayUrl ? (
                    <div className="h-full w-full flex flex-col items-center justify-center p-8 text-center bg-slate-100 dark:bg-slate-800">
                        <div className="text-sm font-medium leading-relaxed max-w-full text-slate-700 dark:text-slate-200 relative overflow-hidden h-[9rem] prose prose-sm dark:prose-invert max-w-none">
                            {post.mediaType === 'zip' ? <p className="mt-8">Conteúdo Compactado (.ZIP)</p> :
                                    <div ref={contentRef}>
                                        {inView ? (
                                            <ScientificContent content={post.description || 'Texto completo'} />
                                        ) : (
                                            <div className="h-20 w-full animate-pulse bg-gray-100 dark:bg-gray-800 rounded-lg" />
                                        )}
                                    </div>}
                            <div className="absolute bottom-0 left-0 right-0 h-6 bg-gradient-to-t from-slate-100 dark:from-slate-800 to-transparent"></div>
                        </div>
                    </div>
                ) : (displayUrl && !hasImageError) ? (
                    priority ? (
                        <div className="relative w-full h-full">
                            <Image
                                src={activeDisplayUrl}
                                alt={`${post.title} - image ${currentImageIndex + 1}`}
                                fill
                                sizes="(max-width: 640px) 100vw, 50vw"
                                className="object-cover object-center"
                                priority={true}
                                fetchPriority="high"
                                loading="eager"
                                onError={handleImageError}
                            />
                        </div>
                    ) : (
                        <div
                            className="relative w-full h-full"
                        >
                            <Image
                                src={activeDisplayUrl}
                                alt={`${post.title} - image ${currentImageIndex + 1}`}
                                fill
                                sizes="(max-width: 640px) 100vw, 50vw"
                                className="object-cover object-center transition-transform duration-700 group-hover:scale-105"
                                priority={priority}
                                fetchPriority="auto"
                                onError={handleImageError}
                            />
                        </div>
                    )
                ) : (post.mediaType as string) === 'placeholder' ? (
                    <div className="h-full w-full bg-brand-yellow/5 border-2 border-dashed border-brand-yellow/30 flex flex-col items-center justify-center p-8 text-center">
                        <span className="material-symbols-outlined text-brand-yellow text-4xl mb-4 opacity-50">image</span>
                        <span className="text-brand-yellow font-bold uppercase tracking-widest text-xs">Aqui fica o seu objeto principal</span>
                        <span className="text-gray-500 text-xs mt-2">Sua mídia (Imagem, Vídeo, Modelo 3D) ou Objeto Pedagógico aparecerá aqui</span>
                    </div>
                ) : (
                    <div className="h-full w-full bg-gradient-to-br from-[#121212] via-[#1A1F2C] to-[#121212] p-6 flex flex-col items-center justify-center text-center relative overflow-hidden select-none">
                        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,204,0,0.06)_0,transparent_70%)] pointer-events-none" />
                        <div className="size-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-3 shadow-inner">
                            <Atom className="w-7 h-7 text-brand-yellow animate-pulse" />
                        </div>
                        <span className="text-xs font-black font-bukra uppercase tracking-wider text-white/90 line-clamp-1 mb-1">
                            {post.title || 'Publicação LabDiv'}
                        </span>
                        <span className="text-[11px] text-gray-400 font-sans line-clamp-2 max-w-[240px]">
                            {post.category || 'Comunicação Científica'} • {post.authors || 'LabDiv'}
                        </span>
                    </div>
                )}

                {hasMultipleImages && (
                    <>
                        {/* Simplified hover effect - removed blur for better performance */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
                        <button onClick={handlePrevImage} aria-label="Imagem Anterior" className="absolute left-2 top-1/2 -translate-y-1/2 size-8 bg-background-dark/60 hover:bg-background-dark/90 text-white rounded-full flex items-center justify-center z-10 hover:scale-110"><ChevronLeft className="w-5 h-5" /></button>
                        <button onClick={handleNextImage} aria-label="Próxima Imagem" className="absolute right-2 top-1/2 -translate-y-1/2 size-8 bg-background-dark/60 hover:bg-background-dark/90 text-white rounded-full flex items-center justify-center z-10 hover:scale-110"><ChevronRight className="w-5 h-5" /></button>
                        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-10 px-2 py-1 rounded-full bg-background-dark/40">
                            {urls.map((_, idx) => (
                                <div key={idx} className={`h-1.5 rounded-full transition-all duration-300 ${idx === currentImageIndex ? 'w-4 bg-white' : 'w-1.5 bg-white/50'}`} />
                            ))}
                        </div>
                        <div className="absolute top-3 left-3 flex items-center gap-1 px-2 py-1 bg-brand-blue text-white text-[10px] font-black uppercase tracking-wider rounded shadow-lg"><Layers className="w-3 h-3" /> Galeria</div>
                    </>
                )}

                {post.mediaType === 'video' && (
                    <div className="absolute inset-0 flex items-center justify-center bg-background-dark/30 transition-colors group-hover:bg-background-dark/40">
                        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white text-primary shadow-2xl transition-transform group-hover:scale-110">
                            <Play className="w-6 h-6 fill-current" />
                        </div>
                    </div>
                )}
            </div>

            <div className="flex flex-col p-4 md:p-6 pt-3 md:pt-4 cursor-default">
                <div data-tour="media-card-interactions" className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-4" onClick={(e) => e.stopPropagation()}>
                        <MediaReaction
                            isActive={liked}
                            count={likes}
                            color="brand-blue"
                            onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                handleLike();
                            }}
                        />
                        <Link href={`/arquivo/${post.id}#comments`} onClick={(e) => e.stopPropagation()} className="text-gray-700 dark:text-gray-200 hover:text-brand-red flex items-center gap-1.5 transition-colors cursor-pointer">
                            <Pencil className="w-5 h-5" />
                            <span className="text-[11px] font-black tabular-nums">{post.commentCount || 0}</span>
                        </Link>
                        <button onClick={(e) => { e.stopPropagation(); setShowShareMenu(true); }} aria-label="Compartilhar" className="text-gray-700 dark:text-gray-200 hover:text-brand-blue cursor-pointer"><Rocket className="w-6 h-6" /></button>
    
                        {displayUrl && <button onClick={(e) => { e.stopPropagation(); setShowDownloadModal(true); }} aria-label="Baixar Arquivo" className="text-gray-700 dark:text-gray-200 hover:text-brand-yellow cursor-pointer"><Download className="w-6 h-6" /></button>}
                    </div>
                    <div className="flex items-center gap-4">
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                openContentReport(post.id);
                            }}
                            className="text-gray-400 hover:text-brand-red transition-colors flex items-center gap-1 group"
                            title="Reportar Problema"
                        >
                            <Flag className="w-5 h-5 group-hover:scale-110 transition-transform" />
                        </button>

                        <button onClick={(e) => { e.stopPropagation(); handleSave(); }} aria-label={saved ? "Remover Favorito" : "Adicionar aos Favoritos"} className="flex items-center gap-1 text-gray-700 dark:text-gray-200 hover:text-brand-yellow cursor-pointer">
                            <Star className={`w-6 h-6 ${saved ? 'fill-current text-brand-yellow' : ''}`} />
                            <span className="text-xs font-bold tabular-nums">{saves}</span>
                        </button>
                    </div>
                </div>

                <div className="space-y-1 cursor-pointer">
                    <div className="text-base sm:text-2xl leading-tight">
                        <span className="font-bold text-gray-800 dark:text-gray-100">
                            {useMemo(() => highlightMatch(post.title, query), [post.title, query])}
                        </span>
                    </div>
                    {post.description && (
                        <div className="text-sm text-gray-600 dark:text-gray-400 overflow-hidden line-clamp-5 relative leading-snug">
                            {useMemo(() => stripMarkdownAndLatex(post.description!), [post.description])}
                        </div>
                    )}
                </div>

                <div className="flex flex-wrap gap-2 mt-3">
                    {post.category && (
                        <span
                            onClick={(e) => {
                                e.stopPropagation(); e.preventDefault();
                                router.push(`/?type=${encodeURIComponent(post.category!)}`);
                            }}
                            className={`px-2 py-0.5 text-[10px] font-black rounded-md uppercase tracking-wide cursor-pointer hover:opacity-80 transition-opacity
                            ${categoryStyle.cardBadge}`}
                        >
                            {post.category}
                        </span>
                    )}
                    {post.institute && post.institute.toLowerCase() !== 'ifusp' && (
                        <span className="px-2 py-0.5 text-[10px] font-black rounded-md uppercase tracking-wide bg-brand-blue/20 text-brand-blue dark:text-brand-yellow border border-brand-blue/30 dark:border-brand-yellow/30">
                            {post.institute.toUpperCase()}
                        </span>
                    )}
                    {post.isGoldenStandard && (
                        <span className="relative overflow-hidden px-2.5 py-1 bg-gradient-to-r from-brand-yellow via-brand-yellow/80 to-brand-yellow text-gray-900 text-[10px] font-black rounded-lg uppercase tracking-wider shadow-[0_0_15px_rgba(255,204,0,0.5)] animate-metallic-shine">
                            <span className="relative z-10 flex items-center gap-1">
                                <Star className="w-3 h-3 fill-current" />
                                Padrão Ouro
                            </span>
                        </span>
                    )}
                    {post.isFeatured && (
                        <span className="relative overflow-hidden px-2.5 py-1 bg-gradient-to-r from-brand-red to-brand-yellow text-white text-[10px] font-black rounded-lg uppercase tracking-wider shadow-[0_0_10px_rgba(230,57,70,0.3)] animate-metallic-shine">
                            <span className="relative z-10">Destaque</span>
                        </span>
                    )}
                    {post.isHistorical && (
                        <span className="relative overflow-hidden px-2.5 py-1 bg-gradient-to-r from-brand-yellow to-brand-yellow/70 text-white text-[10px] font-black rounded-lg uppercase tracking-wider shadow-[0_0_10px_rgba(255,204,0,0.3)] animate-premium-glow">
                            <span className="relative z-10">Marco Histórico</span>
                        </span>
                    )}
                    {post.tags?.map((tag, idx) => {
                        const hash = tag.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
                        const colors = [
                            'bg-brand-blue/10 text-brand-blue border-brand-blue/20',
                            'bg-brand-yellow/10 text-brand-yellow border-brand-yellow/20',
                            'bg-brand-red/10 text-brand-red border-brand-red/20'
                        ];
                        // Cycle based on index + category hash for variety
                        const categoryHash = post.category ? post.category.length : 0;
                        const colorClass = colors[(idx + categoryHash) % colors.length];
                        return (
                            <React.Fragment key={idx}>
                                <span onClick={(e) => { e.stopPropagation(); e.preventDefault(); router.push(`/?q=${tag.replace('#', '')}`); }} className={`px-2 py-0.5 ${colorClass} text-[10px] font-black rounded-md uppercase tracking-wide border transition-all hover:scale-110 cursor-pointer`}>
                                    #{highlightMatch(tag.replace('#', ''), query)}
                                </span>
                            </React.Fragment>
                        );
                    })}
                    <span className="flex items-center gap-1 px-2 py-0.5 bg-brand-yellow/10 text-brand-grey dark:text-brand-yellow text-[10px] font-black rounded-md uppercase tracking-wide border border-brand-yellow/20">
                        <Clock className="w-3 h-3" /> {Math.max(1, post.readingTime || 1)} min
                    </span>
                    {post.views != null && (
                        <span className="flex items-center gap-1 px-2 py-0.5 bg-brand-blue/10 text-brand-blue text-[10px] font-black rounded-md uppercase tracking-wide border border-brand-blue/20">
                            <Eye className="w-3 h-3" /> {post.views}
                        </span>
                    )}
                </div>
            </div>

            {showShareMenu && <ShareMenu id={post.id} title={post.title} author={post.authors} onClose={() => setShowShareMenu(false)} />}
            {showCollectionManager && <CollectionManager submissionId={post.id} userId={userId} onClose={() => setShowCollectionManager(false)} />}
            {showDownloadModal && <DownloadModal id={post.id} title={post.title} authors={post.authors} avatarUrl={post.avatarUrl} description={post.description} mediaUrl={displayUrl} onClose={() => setShowDownloadModal(false)} />}
        </div >
        </LocalErrorBoundary>
    );
});

MediaCard.displayName = 'MediaCard';
