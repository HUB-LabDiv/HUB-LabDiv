'use client';

/*!
 * Hub de Comunicação Científica Lab-Div V3.0
 * Copyright (C) 2026 João Paulo Stangorlini de Carvalho
 * * Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
 * sob os termos da Licença Pública Geral Affero GNU (AGPLv3) conforme
 * publicada pela Free Software Foundation.
 * * Este programa é distribuído na esperança de que seja útil, mas SEM
 * QUALQUER GARANTIA; sem mesmo a garantia implícita de COMERCIALIZAÇÃO
 * ou ADEQUAÇÃO A UM DETERMINADO FIM.
 */


import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { m, AnimatePresence } from 'framer-motion';

export function PresenceIndicator({ submissionId }: { submissionId: string }) {
    const [presenceCount, setPresenceCount] = useState(0);

    useEffect(() => {
        const channel = supabase.channel(`reading:${submissionId}`, {
            config: {
                presence: {
                    key: 'user',
                },
            },
        });

        channel
            .on('presence', { event: 'sync' }, () => {
                const state = channel.presenceState();
                const count = Object.keys(state).length;
                setPresenceCount(count);
            })
            .on('presence', { event: 'join' }, ({ newPresences }) => {
                // Handle join if needed
            })
            .on('presence', { event: 'leave' }, ({ leftPresences }) => {
                // Handle leave if needed
            })
            .subscribe(async (status) => {
                if (status === 'SUBSCRIBED') {
                    await channel.track({
                        online_at: new Date().toISOString(),
                    });
                }
            });

        return () => {
            supabase.removeChannel(channel);
        };
    }, [submissionId]);

    if (presenceCount === 0) return null;

    return (
        <AnimatePresence>
            <m.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="fixed bottom-44 xl:bottom-20 right-4 z-[80] flex items-center gap-2 px-3 py-1.5 bg-brand-red/10 border border-brand-red/20 rounded-full text-brand-red text-xs font-bold shadow-lg backdrop-blur-sm"
            >
                <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-red opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-red"></span>
                </span>
                🔥 {presenceCount === 1 ? '1 aluno lendo agora' : `${presenceCount} alunos lendo agora`}
            </m.div>
        </AnimatePresence>
    );
}
